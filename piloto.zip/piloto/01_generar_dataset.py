"""
PILOTO - Paso 1: Generacion del dataset piloto (sustituto temporal) - v3
--------------------------------------------------------------------------
CORRECCION DE ALINEACION v3 (tras recibir los parametros OFICIALES y
exactos del validador de SUNEDU, capturados directamente de
https://siucarne.sunedu.gob.pe/carne/validacion):

  Tamano archivo ..... 4 KB a 50 KB               (v2 no lo verificaba bien)
  Dimension ancho ..... 240 px (exacto)
  Dimension alto ....... 288 px (exacto)
  Resolucion ........... 300 dpi (exacto)
  Fondo blanco ......... R,G,B cada uno entre 220 y 255 (HEX #dcdcdc-#ffffff)
  Ojo izquierdo ........ X entre 24-120, Y entre 55-180
  Ojo derecho .......... X entre 80-185, Y entre 50-180
  Boca ................. X entre 50-161, Y entre 70-252
  (cualitativos, del texto "Caracteristicas"): sin gorra, sin gafas/lentes
  oscuros (excepto invidentes), sin sellos ni enmendaduras, encuadre desde
  los hombros, sin mostrar medio cuerpo.

v2 probaba "ojos_cerrados"/"boca_abierta" como si SUNEDU verificara el
ESTADO de ojos/boca -- el validador oficial en realidad verifica la
POSICION (coordenadas X,Y) de ojos y boca dentro de rangos fijos, es decir,
un criterio de ENCUADRE/CENTRADO del rostro, no de expresion facial. Esta
version corrige esa idea equivocada y ademas agrega "con_gorra" (criterio
oficial que v2 no cubria) y "tamano_invalido" (tampoco cubierto).

IMPORTANTE: este dataset sigue siendo 100% SINTETICO (PIL), solo para
probar que el CODIGO del pipeline funciona. Con fotografias reales, la
etiqueta Conforme/No conforme se obtiene sometiendo cada foto al validador
oficial de SUNEDU, no con la funcion simulada de este script.
"""
import os, random, json
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

random.seed(42)
np.random.seed(42)

OUT_DIR = "/home/claude/piloto/data_raw"
os.makedirs(OUT_DIR, exist_ok=True)

# Geometria de referencia (imagen 240x288, sin defectos): con esta geometria,
# los ojos y la boca caen DENTRO de los rangos oficiales de SUNEDU (ver
# verificacion mas abajo en el script de auditoria).
W0, H0 = 240, 288
CX0, CY0 = W0 // 2, int(H0 * 0.42)   # = 120, 120
R0 = int(min(W0, H0) * 0.24)          # = 57

def draw_face_like(size, bg_color, blur_radius=0, jitter=0, pose_shift=0.0,
                    accessory=False, gorra=False):
    """Dibuja una imagen simple tipo 'rostro'.
    pose_shift: desplaza el rostro horizontalmente (fraccion del ancho) -> saca
                los ojos/boca de las coordenadas validas de SUNEDU.
    accessory: dibuja una barra oscura sobre los ojos (lentes oscuros).
    gorra: dibuja un bloque oscuro sobre la parte superior de la cabeza (gorra).
    """
    img = Image.new("RGB", size, bg_color)
    d = ImageDraw.Draw(img)
    w, h = size
    cx = int(w // 2 + pose_shift * w)
    cy = int(h * 0.42)
    r = int(min(w, h) * 0.24)
    skin = (222 + random.randint(-10, 10), 184 + random.randint(-10, 10), 154 + random.randint(-10, 10))
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=skin)

    eye_y = cy - int(r * 0.15)
    ex_l = cx - int(r * 0.4)
    ex_r = cx + int(r * 0.4)
    d.ellipse([ex_l - 4, eye_y - 4, ex_l + 4, eye_y + 4], fill=(40, 30, 20))
    d.ellipse([ex_r - 4, eye_y - 4, ex_r + 4, eye_y + 4], fill=(40, 30, 20))

    if accessory:
        d.rectangle([ex_l - 8, eye_y - 5, ex_r + 8, eye_y + 5], outline=(15, 15, 15), width=4)

    mouth_y = cy + int(r * 0.375)
    d.arc([cx - int(r*0.3), cy + int(r*0.2), cx + int(r*0.3), cy + int(r*0.55)], start=20, end=160, fill=(120,60,50), width=3)

    if gorra:
        d.rectangle([cx - r - 5, cy - r - 22, cx + r + 5, cy - int(r*0.55)], fill=(25, 25, 30))

    # "hombros"
    d.rectangle([int(w*0.2), int(h*0.75), int(w*0.8), h], fill=(60+random.randint(-20,20), 70+random.randint(-20,20), 110+random.randint(-20,20)))
    if jitter:
        arr = np.array(img).astype(np.int16)
        noise = np.random.randint(-jitter, jitter, arr.shape)
        arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
        img = Image.fromarray(arr)
    if blur_radius:
        img = img.filter(ImageFilter.GaussianBlur(blur_radius))
    return img

records = []
img_counter = 1
group_counter = 1

def new_id():
    global img_counter
    s = f"PIL_{img_counter:04d}"
    img_counter += 1
    return s

def new_group():
    global group_counter
    s = f"EST_{group_counter:03d}"
    group_counter += 1
    return s

def make(n, defecto, size=(240, 288), dpi=(300, 300), bg_choices=None, quality=90, **kwargs):
    for _ in range(n):
        gid = new_group()
        iid = new_id()
        bg = random.choice(bg_choices) if bg_choices else (255, 255, 255)
        sz = random.choice(size) if isinstance(size, list) else size
        img = draw_face_like(sz, bg,
                              blur_radius=kwargs.get("blur_radius", 0), jitter=kwargs.get("jitter", 3),
                              pose_shift=kwargs.get("pose_shift", 0.0),
                              accessory=kwargs.get("accessory", False),
                              gorra=kwargs.get("gorra", False))
        fname = f"{iid}.jpg"
        img.save(os.path.join(OUT_DIR, fname), "JPEG", quality=quality, dpi=dpi)
        records.append(dict(image_id=iid, file_name=fname, group_id=gid, defecto=defecto))

# ---- 1) 22 imagenes "candidatas conformes": cumplen los 10 criterios oficiales
make(22, "ninguno_simulado")

# ---- Criterios oficiales de SUNEDU (parametros exactos) ----
make(8, "fondo_no_blanco", bg_choices=[(180, 200, 230), (200, 220, 180), (230, 230, 150)])
make(6, "dimensiones_incorrectas", size=[(180, 220), (300, 350), (240, 240)])
make(5, "baja_resolucion_dpi", dpi=(72, 72))
make(5, "tamano_invalido", quality=100, jitter=30)   # ruido alto + calidad 100 -> JPG mas pesado, fuera de 4-50KB
make(6, "rostro_descentrado", pose_shift=0.22)        # saca ojos/boca de las coordenadas validas SUNEDU
make(4, "con_lentes_oscuros", accessory=True)
make(4, "con_gorra", gorra=True)

# ---- Criterio ADICIONAL propio (no forma parte de la tabla oficial de SUNEDU,
#      es un pre-filtro de calidad que el investigador puede aplicar antes de
#      someter la foto al validador oficial) ----
make(5, "nitidez_baja", blur_radius=4)

n_before_dup_leak = len(records)

# ---- Duplicados: mismo estudiante con 2 fotografias ----
dup_source = random.sample(records, 8)
for rec in dup_source:
    iid = new_id()
    fname = f"{iid}.jpg"
    src_path = os.path.join(OUT_DIR, rec["file_name"])
    img = Image.open(src_path)
    img.save(os.path.join(OUT_DIR, fname), "JPEG", quality=90, dpi=img.info.get("dpi", (300, 300)))
    records.append(dict(image_id=iid, file_name=fname, group_id=rec["group_id"], defecto=rec["defecto"] + "_duplicado_mismo_grupo"))

# ---- Duplicados EXACTOS de bytes ----
exact_dup_source = random.sample(records[:n_before_dup_leak], 3)
for rec in exact_dup_source:
    iid = new_id()
    fname = f"{iid}.jpg"
    src_path = os.path.join(OUT_DIR, rec["file_name"])
    with open(src_path, "rb") as f:
        content = f.read()
    with open(os.path.join(OUT_DIR, fname), "wb") as f:
        f.write(content)
    records.append(dict(image_id=iid, file_name=fname, group_id=new_group(), defecto="duplicado_exacto_bytes"))

# ---- Archivos corruptos ----
for _ in range(4):
    iid = new_id()
    fname = f"{iid}.jpg"
    with open(os.path.join(OUT_DIR, fname), "wb") as f:
        f.write(os.urandom(120))
    records.append(dict(image_id=iid, file_name=fname, group_id=new_group(), defecto="archivo_corrupto"))

with open("/home/claude/piloto/evidencias/generacion_dataset_log.json", "w") as f:
    json.dump({"total_generado": len(records), "registros": records}, f, indent=2, ensure_ascii=False)

print(f"[GENERACION] Total de archivos generados en data_raw/: {len(records)}")
print(f"[GENERACION] Distribucion de 'defecto' simulado (parametros OFICIALES de SUNEDU):")
from collections import Counter
for k, v in Counter([r['defecto'] for r in records]).items():
    print(f"   - {k}: {v}")
