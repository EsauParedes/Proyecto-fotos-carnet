"""
PILOTO - Paso 2: P01 (registro) + P02 (auditoria) del protocolo V1.2 - v3
---------------------------------------------------------------------------
CORRECCION DE ALINEACION v3: usa los parametros OFICIALES Y EXACTOS
capturados directamente del validador de SUNEDU
(https://siucarne.sunedu.gob.pe/carne/validacion):

  tamano_kb en [4, 50]
  ancho_px == 240, alto_px == 288 (exacto)
  resolucion_dpi == 300 (exacto)
  fondo blanco: R,G,B cada uno en [220, 255]  (HEX #dcdcdc - #ffffff)
  ojo_izq_x en [24,120], ojo_izq_y en [55,180]
  ojo_der_x en [80,185], ojo_der_y en [50,180]
  boca_x en [50,161],    boca_y en [70,252]
  + cualitativos: sin_gorra, sin_lentes_oscuros (de las "Caracteristicas")
  + ADICIONAL (no oficial): nitidez (varianza_laplaciano >= 100), pre-filtro
    propio del investigador, no verificado por el validador de SUNEDU.

v2 evaluaba "rostro_frontal" con un proxy de centroide de piel y
"ojos_abiertos"/"boca_cerrada" como estados -- ninguno de los dos es lo que
el validador oficial realmente comprueba. Esta v3 detecta la POSICION
(coordenadas X,Y en pixeles) del centro de cada ojo y de la boca, y las
compara contra los 6 rangos oficiales.

*** SUSTITUTO TEMPORAL ***
Esta funcion es un STUB. Con fotografias reales, la etiqueta Conforme/No
conforme se obtiene sometiendo cada foto al validador oficial de SUNEDU, no
con esta funcion.
"""
import os, hashlib, json, csv
from PIL import Image
import numpy as np
import cv2

RAW_DIR = "/home/claude/piloto/data_raw"
EVID_DIR = "/home/claude/piloto/evidencias"

# ---------- Rangos oficiales (capturados de siucarne.sunedu.gob.pe) ----------
RANGO_TAMANO_KB = (4, 50)
RANGO_ANCHO_PX = (240, 240)
RANGO_ALTO_PX = (288, 288)
RANGO_DPI = (300, 300)
RANGO_RGB_FONDO = (220, 255)
RANGO_OJO_IZQ_X, RANGO_OJO_IZQ_Y = (24, 120), (55, 180)
RANGO_OJO_DER_X, RANGO_OJO_DER_Y = (80, 185), (50, 180)
RANGO_BOCA_X, RANGO_BOCA_Y = (50, 161), (70, 252)

def sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()

def fondo_rgb_promedio(img_rgb):
    """Promedio R,G,B del borde de la imagen (proxy de 'fondo')."""
    arr = np.array(img_rgb)
    h, w, _ = arr.shape
    border = np.concatenate([
        arr[0:int(h*0.08), :, :].reshape(-1, 3),
        arr[-int(h*0.08):, :, :].reshape(-1, 3),
        arr[:, 0:int(w*0.08), :].reshape(-1, 3),
        arr[:, -int(w*0.08):, :].reshape(-1, 3),
    ])
    return border[:, 0].mean(), border[:, 1].mean(), border[:, 2].mean()

def sharpness_laplacian(img_rgb):
    gray = cv2.cvtColor(np.array(img_rgb), cv2.COLOR_RGB2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())

def detectar_ojos_boca_xy(img_rgb):
    """Heuristica: localiza los 2 blobs oscuros mas prominentes en la banda
    ocular (ojos) y el area oscura/rojiza en la banda de la boca; devuelve
    sus coordenadas (x,y) en pixeles, con origen en la esquina superior
    izquierda -- mismo sistema de referencia que usa la tabla oficial."""
    arr = np.array(img_rgb)
    h, w, _ = arr.shape
    gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)

    # Banda ocular amplia (toda la posible zona de ojos)
    y0, y1 = int(h*0.25), int(h*0.48)
    banda = gray[y0:y1, :]
    _, thresh = cv2.threshold(banda, 90, 255, cv2.THRESH_BINARY_INV)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    blobs = []
    for c in contours:
        x, y, cw, ch = cv2.boundingRect(c)
        if cw * ch < 6 or cw > 30:  # descarta ruido y la barra de lentes (muy ancha)
            continue
        blobs.append((x + cw / 2, y0 + y + ch / 2))
    blobs.sort(key=lambda p: p[0])  # ordenar de izquierda a derecha

    if len(blobs) >= 2:
        ojo_izq = blobs[0]
        ojo_der = blobs[-1]
    elif len(blobs) == 1:
        ojo_izq = ojo_der = blobs[0]
    else:
        ojo_izq = ojo_der = (None, None)

    # Banda de la boca
    y0b, y1b = int(h*0.44), int(h*0.62)
    region = arr[y0b:y1b, :, :]
    r, g, b = region[..., 0].astype(int), region[..., 1].astype(int), region[..., 2].astype(int)
    oscuro = (r < 150) & (g < 90) & (b < 90)
    ys, xs = np.where(oscuro)
    if len(xs) > 0:
        boca = (float(xs.mean()), float(y0b + ys.mean()))
    else:
        boca = (None, None)

    return ojo_izq, ojo_der, boca

def detectar_accesorio(img_rgb):
    """Barra oscura horizontal continua sobre los ojos (proxy de lentes oscuros)."""
    arr = np.array(img_rgb)
    h, w, _ = arr.shape
    banda = arr[int(h*0.34):int(h*0.44), int(w*0.25):int(w*0.75)]
    gray = cv2.cvtColor(banda, cv2.COLOR_RGB2GRAY)
    filas_oscuras = (gray < 80).mean(axis=1)
    max_cobertura = float(filas_oscuras.max()) if filas_oscuras.size else 0.0
    return max_cobertura <= 0.35  # True = sin lentes oscuros

def detectar_gorra(img_rgb):
    """Bloque oscuro no-piel en la franja superior de la cabeza (proxy de gorra)."""
    arr = np.array(img_rgb)
    h, w, _ = arr.shape
    banda = arr[int(h*0.06):int(h*0.20), int(w*0.30):int(w*0.70)]
    gray = cv2.cvtColor(banda, cv2.COLOR_RGB2GRAY)
    frac_oscuro = float((gray < 60).mean())
    return frac_oscuro <= 0.15  # True = sin gorra

def en_rango(valor, rango):
    if valor is None:
        return False
    return rango[0] <= valor <= rango[1]

def validador_sunedu_SIMULADO(width, height, dpi, tamano_kb, rgb_fondo,
                                ojo_izq, ojo_der, boca, sin_lentes, sin_gorra, cumple_formato):
    """Stub con los parametros OFICIALES Y EXACTOS de SUNEDU. Ver advertencia arriba."""
    fallos = []
    if not (RANGO_ANCHO_PX[0] <= width <= RANGO_ANCHO_PX[1]) or not (RANGO_ALTO_PX[0] <= height <= RANGO_ALTO_PX[1]):
        fallos.append("dimension_incorrecta")
    if dpi is None or not (RANGO_DPI[0] <= dpi <= RANGO_DPI[1]):
        fallos.append("resolucion_dpi_incorrecta")
    if not (RANGO_TAMANO_KB[0] <= tamano_kb <= RANGO_TAMANO_KB[1]):
        fallos.append("tamano_archivo_fuera_de_rango")
    r, g, b = rgb_fondo
    if not all(RANGO_RGB_FONDO[0] <= c <= RANGO_RGB_FONDO[1] for c in (r, g, b)):
        fallos.append("fondo_no_blanco")
    if not (en_rango(ojo_izq[0], RANGO_OJO_IZQ_X) and en_rango(ojo_izq[1], RANGO_OJO_IZQ_Y)):
        fallos.append("ojo_izquierdo_fuera_de_posicion")
    if not (en_rango(ojo_der[0], RANGO_OJO_DER_X) and en_rango(ojo_der[1], RANGO_OJO_DER_Y)):
        fallos.append("ojo_derecho_fuera_de_posicion")
    if not (en_rango(boca[0], RANGO_BOCA_X) and en_rango(boca[1], RANGO_BOCA_Y)):
        fallos.append("boca_fuera_de_posicion")
    if not sin_lentes:
        fallos.append("con_lentes_oscuros")
    if not sin_gorra:
        fallos.append("con_gorra")
    if not cumple_formato:
        fallos.append("formato_invalido")
    conforme = len(fallos) == 0
    return conforme, fallos

# ---------- Carga y registro (P01) ----------
files = sorted(os.listdir(RAW_DIR))
metadata_rows = []
hashes_seen = {}
n_total = len(files); n_corruptos = 0; n_duplicados = 0; n_validos = 0

for fname in files:
    path = os.path.join(RAW_DIR, fname)
    image_id = os.path.splitext(fname)[0]
    file_size_kb = round(os.path.getsize(path) / 1024, 2)
    file_hash = sha256_of_file(path)

    row = dict(id_imagen=image_id, nombre_archivo=fname, tamano_kb=file_size_kb,
               sha256=file_hash, status="pendiente", reason="")

    try:
        img = Image.open(path)
        img.verify()
        img = Image.open(path).convert("RGB")
    except Exception as e:
        n_corruptos += 1
        row["status"] = "excluido"
        row["reason"] = f"archivo_corrupto: {type(e).__name__}"
        metadata_rows.append(row)
        continue

    width, height = img.size
    dpi = img.info.get("dpi", (None, None))[0]
    cumple_formato = fname.lower().endswith((".jpg", ".jpeg"))

    if file_hash in hashes_seen:
        n_duplicados += 1
        row["status"] = "excluido"
        row["reason"] = f"duplicado_exacto_de:{hashes_seen[file_hash]}"
        row.update(dict(ancho_px=width, alto_px=height, resolucion_dpi=dpi))
        metadata_rows.append(row)
        continue
    hashes_seen[file_hash] = image_id

    r_bg, g_bg, b_bg = fondo_rgb_promedio(img)
    sharp = sharpness_laplacian(img)
    ojo_izq, ojo_der, boca = detectar_ojos_boca_xy(img)
    sin_lentes = detectar_accesorio(img)
    sin_gorra = detectar_gorra(img)

    conforme, fallos = validador_sunedu_SIMULADO(
        width, height, dpi, file_size_kb, (r_bg, g_bg, b_bg),
        ojo_izq, ojo_der, boca, sin_lentes, sin_gorra, cumple_formato)

    # Criterio ADICIONAL (no oficial): nitidez, como pre-filtro propio
    if sharp < 100:
        fallos = fallos + ["nitidez_insuficiente_[criterio_adicional_no_oficial]"]
        conforme_oficial = conforme
        conforme = False
    else:
        conforme_oficial = conforme

    row.update(dict(
        ancho_px=width, alto_px=height, resolucion_dpi=dpi,
        bg_r=round(r_bg, 1), bg_g=round(g_bg, 1), bg_b=round(b_bg, 1),
        fondo_blanco=int(all(RANGO_RGB_FONDO[0] <= c <= RANGO_RGB_FONDO[1] for c in (r_bg, g_bg, b_bg))),
        varianza_laplaciano=round(sharp, 1),
        ojo_izq_x=ojo_izq[0], ojo_izq_y=ojo_izq[1],
        ojo_der_x=ojo_der[0], ojo_der_y=ojo_der[1],
        boca_x=boca[0], boca_y=boca[1],
        sin_lentes_oscuros=int(sin_lentes), sin_gorra=int(sin_gorra),
        cumple_formato=int(cumple_formato),
        etiqueta_sunedu_oficial="Conforme" if conforme_oficial else "No conforme",
        etiqueta_sunedu="Conforme" if conforme else "No conforme",
        criterios_incumplidos=";".join(fallos) if fallos else "",
        status="valido", reason=""
    ))
    n_validos += 1
    metadata_rows.append(row)

os.makedirs(EVID_DIR, exist_ok=True)
meta_fields = ["id_imagen", "nombre_archivo", "ancho_px", "alto_px", "resolucion_dpi", "tamano_kb",
               "bg_r", "bg_g", "bg_b", "fondo_blanco",
               "ojo_izq_x", "ojo_izq_y", "ojo_der_x", "ojo_der_y", "boca_x", "boca_y",
               "sin_lentes_oscuros", "sin_gorra", "cumple_formato",
               "varianza_laplaciano", "etiqueta_sunedu_oficial", "etiqueta_sunedu",
               "criterios_incumplidos", "status", "reason", "sha256"]
with open(os.path.join(EVID_DIR, "dataset_metadata.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=meta_fields, extrasaction="ignore")
    w.writeheader()
    for r in metadata_rows:
        w.writerow(r)
with open(os.path.join(EVID_DIR, "dataset_audit.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=meta_fields, extrasaction="ignore")
    w.writeheader()
    for r in metadata_rows:
        w.writerow(r)

resumen = dict(
    n_total=n_total, n_validos=n_validos, n_corruptos=n_corruptos, n_duplicados=n_duplicados,
    n_conforme_oficial=sum(1 for r in metadata_rows if r.get("etiqueta_sunedu_oficial") == "Conforme"),
    n_conforme_con_criterio_adicional=sum(1 for r in metadata_rows if r.get("etiqueta_sunedu") == "Conforme"),
    parametros_oficiales_sunedu={
        "tamano_kb": RANGO_TAMANO_KB, "ancho_px": RANGO_ANCHO_PX, "alto_px": RANGO_ALTO_PX,
        "resolucion_dpi": RANGO_DPI, "rgb_fondo": RANGO_RGB_FONDO,
        "ojo_izq_x": RANGO_OJO_IZQ_X, "ojo_izq_y": RANGO_OJO_IZQ_Y,
        "ojo_der_x": RANGO_OJO_DER_X, "ojo_der_y": RANGO_OJO_DER_Y,
        "boca_x": RANGO_BOCA_X, "boca_y": RANGO_BOCA_Y,
    },
    fuente="https://siucarne.sunedu.gob.pe/carne/validacion (capturado por el investigador)",
)
with open(os.path.join(EVID_DIR, "resumen_auditoria.json"), "w") as f:
    json.dump(resumen, f, indent=2, ensure_ascii=False)

print(f"[AUDITORIA] Total archivos: {n_total}")
print(f"[AUDITORIA] Validos: {n_validos} | Corruptos: {n_corruptos} | Duplicados exactos: {n_duplicados}")
print(f"[AUDITORIA] Conforme segun criterios OFICIALES SUNEDU: {resumen['n_conforme_oficial']}")
print(f"[AUDITORIA] Conforme incluyendo criterio adicional (nitidez): {resumen['n_conforme_con_criterio_adicional']}")
