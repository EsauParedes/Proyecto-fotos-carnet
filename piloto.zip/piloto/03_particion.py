"""
PILOTO - Paso 3: P03 (particion) del protocolo V1.1
------------------------------------------------------
Prueba en dos tiempos, tal como exige el laboratorio Semana 4:
  (a) Particion INGENUA (aleatoria simple, ignorando group_id) -> se
      audita si genera fuga de datos (mismo group_id en mas de una
      particion).
  (b) Si hay fuga -> se corrige con particion agrupada (GroupShuffleSplit)
      y se vuelve a auditar hasta confirmar solapamiento = 0.
"""
import csv, json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GroupShuffleSplit

EVID = "/home/claude/piloto/evidencias"

df = pd.read_csv(f"{EVID}/dataset_metadata.csv")
df_valid = df[df["status"] == "valido"].copy()
df_valid["nombre_archivo"] = df_valid["nombre_archivo"].astype(str)

# Necesitamos el group_id, que no viaja en dataset_metadata.csv (solo en el log de generacion).
gen_log = json.load(open("/home/claude/piloto/evidencias/generacion_dataset_log.json"))
id2group = {r["image_id"]: r["group_id"] for r in gen_log["registros"]}
df_valid["group_id"] = df_valid["id_imagen"].map(id2group)

def overlap_groups(df_split):
    sets = {s: set(df_split[df_split["split"] == s]["group_id"]) for s in ["train", "val", "test"]}
    ov_tv = sets["train"] & sets["val"]
    ov_tt = sets["train"] & sets["test"]
    ov_vt = sets["val"] & sets["test"]
    return ov_tv, ov_tt, ov_vt

# ---------- (a) Particion INGENUA (aleatoria, sin agrupar) ----------
rng = np.random.RandomState(42)
idx = df_valid.index.values.copy()
rng.shuffle(idx)
n = len(idx)
n_train = int(n * 0.70)
n_val = int(n * 0.15)
split_naive = pd.Series(index=idx, dtype=object)
split_naive.loc[idx[:n_train]] = "train"
split_naive.loc[idx[n_train:n_train + n_val]] = "val"
split_naive.loc[idx[n_train + n_val:]] = "test"
df_valid["split"] = split_naive.values

ov_tv, ov_tt, ov_vt = overlap_groups(df_valid)
n_leak_groups = len(ov_tv | ov_tt | ov_vt)

print("[PARTICION-INGENUA] (a) Particion aleatoria simple (sin agrupar por estudiante)")
print(f"[PARTICION-INGENUA] Grupos solapados train/val: {len(ov_tv)} | train/test: {len(ov_tt)} | val/test: {len(ov_vt)}")
print(f"[PARTICION-INGENUA] INCIDENCIA: {n_leak_groups} grupo(s) (estudiante) aparecen en mas de una particion -> data leakage.")

df_valid.drop(columns=["split"]).to_csv(f"{EVID}/_debug_pre_particion.csv", index=False)
with open(f"{EVID}/incidencia_particion_ingenua.json", "w") as f:
    json.dump({
        "metodo": "aleatoria_simple_sin_agrupar",
        "grupos_solapados_train_val": sorted(ov_tv),
        "grupos_solapados_train_test": sorted(ov_tt),
        "grupos_solapados_val_test": sorted(ov_vt),
        "total_grupos_con_fuga": n_leak_groups,
        "conclusion": "Se confirma fuga de datos (data leakage). Se requiere particion agrupada por group_id (cambio metodologico segun clasificacion del laboratorio Semana 4)."
    }, f, indent=2, ensure_ascii=False)

# ---------- (b) Particion CORREGIDA agrupada por group_id ----------
groups = df_valid["group_id"].values
gss1 = GroupShuffleSplit(n_splits=1, train_size=0.70, random_state=42)
train_idx, rest_idx = next(gss1.split(df_valid, groups=groups))

rest_df = df_valid.iloc[rest_idx]
rest_groups = rest_df["group_id"].values
gss2 = GroupShuffleSplit(n_splits=1, train_size=0.5, random_state=42)  # 15/15 del 30% restante
val_idx_rel, test_idx_rel = next(gss2.split(rest_df, groups=rest_groups))

final_split = pd.Series(index=df_valid.index, dtype=object)
final_split.iloc[train_idx] = "train"
rest_index_arr = rest_df.index.values
final_split.loc[rest_index_arr[val_idx_rel]] = "val"
final_split.loc[rest_index_arr[test_idx_rel]] = "test"
df_valid["split"] = final_split.values

ov_tv2, ov_tt2, ov_vt2 = overlap_groups(df_valid)
n_leak_groups2 = len(ov_tv2 | ov_tt2 | ov_vt2)

counts = df_valid["split"].value_counts().to_dict()
class_by_split = df_valid.groupby(["split", "etiqueta_sunedu"]).size().unstack(fill_value=0)

print("\n[PARTICION-CORREGIDA] (b) Particion agrupada por group_id (GroupShuffleSplit)")
print(f"[PARTICION-CORREGIDA] Grupos solapados train/val: {len(ov_tv2)} | train/test: {len(ov_tt2)} | val/test: {len(ov_vt2)}")
print(f"[PARTICION-CORREGIDA] Total grupos con fuga: {n_leak_groups2} (debe ser 0)")
print(f"[PARTICION-CORREGIDA] Distribucion de imagenes por particion: {counts}")
print(f"[PARTICION-CORREGIDA] Distribucion de clases por particion:\n{class_by_split}")

assert n_leak_groups2 == 0, "Aun existe fuga de datos tras la particion agrupada"

df_valid[["id_imagen","nombre_archivo","group_id","etiqueta_sunedu","split"]].to_csv(
    f"{EVID}/dataset_split.csv", index=False)

with open(f"{EVID}/resumen_particion.json", "w") as f:
    json.dump({
        "metodo": "GroupShuffleSplit_por_group_id_seed42",
        "grupos_con_fuga": n_leak_groups2,
        "conteo_por_particion": counts,
        "clases_por_particion": class_by_split.to_dict(),
    }, f, indent=2, ensure_ascii=False)
