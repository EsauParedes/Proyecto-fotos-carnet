"""
PILOTO - Paso 4: P04 (preprocesamiento) + P05 (entrenamiento reducido) - v2
-------------------------------------------------------------------------------
CORRECCION DE ALINEACION: la v1 solo calculaba 5 de las 6+ metricas que exige
el Protocolo V1.2 (seccion 2.11): faltaban AUC-ROC y Specificity. Tambien se
agregan las columnas model/seed/probabilidad en las predicciones (formato
exacto de P09) y el numero de parametros del modelo (evidencia P05).

*** SUSTITUTO TEMPORAL ***
Este sandbox de piloto NO tiene acceso a internet hacia los servidores de
pesos preentrenados de Keras/TensorFlow (storage.googleapis.com), por lo
que NO es posible descargar ResNet-50 ni VGG-16 con pesos ImageNet aqui.
Para probar la MECANICA del pipeline (carga, augmentation, entrenamiento,
prediccion, metricas, guardado) se usan dos clasificadores ligeros de
scikit-learn como "stand-in":
   - stub_ResNet50 -> RandomForestClassifier
   - stub_VGG16    -> LogisticRegression
Ambos reciben el mismo vector de caracteristicas (imagen redimensionada,
escala de grises, aplanada). En la ejecucion real (Google Colab, con
internet), estos dos stubs se REEMPLAZAN por ResNet-50 y VGG-16 reales con
transferencia de aprendizaje, segun el protocolo (seccion 2.6). El notebook
Piloto_Colab_UNAJ.ipynb ya incluye ese codigo real completo con fallback.
"""
import os, json, csv, random, time
import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance

random.seed(42)
np.random.seed(42)

RAW_DIR = "/home/claude/piloto/data_raw"
EVID = "/home/claude/piloto/evidencias"
IMG_SIZE = (32, 32)  # reducido para velocidad del piloto (real: 224x224x3)

df = pd.read_csv(f"{EVID}/dataset_split.csv")

def load_and_preprocess(fname, augment=False):
    img = Image.open(os.path.join(RAW_DIR, fname)).convert("RGB").resize(IMG_SIZE)
    if augment:
        angle = random.uniform(-10, 10)
        img = img.rotate(angle, fillcolor=(255, 255, 255))
        img = ImageEnhance.Brightness(img).enhance(random.uniform(0.8, 1.2))
        img = ImageEnhance.Contrast(img).enhance(random.uniform(0.85, 1.15))
    arr = np.asarray(img.convert("L"), dtype=np.float32) / 255.0  # normalizacion [0,1]
    return arr.flatten()

X, y, split_arr, ids = [], [], [], []
n_augmented = 0
for _, row in df.iterrows():
    augment = (row["split"] == "train")
    vec = load_and_preprocess(row["nombre_archivo"], augment=augment)
    X.append(vec)
    y.append(1 if row["etiqueta_sunedu"] == "Conforme" else 0)
    split_arr.append(row["split"])
    ids.append(row["id_imagen"])
    if augment:
        n_augmented += 1

X = np.array(X); y = np.array(y); split_arr = np.array(split_arr); ids = np.array(ids)
print(f"[PREPROCESAMIENTO] Imagenes procesadas: {len(X)} (redimensionadas a {IMG_SIZE}, normalizadas [0,1])")
print(f"[PREPROCESAMIENTO] Augmentation aplicado solo a 'train': {n_augmented} imagenes")

Xtr, ytr = X[split_arr == "train"], y[split_arr == "train"]
Xval, yval = X[split_arr == "val"], y[split_arr == "val"]
Xte, yte = X[split_arr == "test"], y[split_arr == "test"]
ids_te = ids[split_arr == "test"]

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                              balanced_accuracy_score, confusion_matrix, roc_auc_score)

SEEDS = [10, 20]  # piloto reducido: 2 semillas (real: 5, seccion 2.8 del protocolo)
resultados = []
predicciones_finales = {}

configs = {
    "stub_ResNet50": lambda seed: RandomForestClassifier(n_estimators=150, max_depth=12, random_state=seed),
    "stub_VGG16": lambda seed: LogisticRegression(max_iter=500, C=1.0, random_state=seed),
}

def contar_parametros(clf, arch_name):
    """Numero de 'parametros' del stub, como evidencia analoga al conteo de
    pesos de una CNN real (protocolo 2.11). No comparable en magnitud con
    ResNet-50/VGG-16 (25M-138M parametros); solo prueba que el campo existe
    y se guarda en la evidencia."""
    if arch_name == "stub_ResNet50":
        return int(sum(t.tree_.node_count for t in clf.estimators_))
    else:
        return int(clf.coef_.size + clf.intercept_.size)

for arch_name, builder in configs.items():
    for seed in SEEDS:
        t0 = time.time()
        clf = builder(seed)
        clf.fit(Xtr, ytr)
        train_time = time.time() - t0

        val_pred = clf.predict(Xval)
        t1 = time.time()
        test_pred = clf.predict(Xte)
        test_proba = clf.predict_proba(Xte)[:, 1]
        infer_time_per_img = (time.time() - t1) / max(len(Xte), 1)

        cm = confusion_matrix(yte, test_pred, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
        specificity = tn / (tn + fp) if (tn + fp) > 0 else float("nan")
        try:
            auc = roc_auc_score(yte, test_proba) if len(set(yte)) > 1 else float("nan")
        except ValueError:
            auc = float("nan")

        n_params = contar_parametros(clf, arch_name)

        metrics = dict(
            arch=arch_name, seed=seed,
            accuracy=accuracy_score(yte, test_pred),
            precision=precision_score(yte, test_pred, zero_division=0),
            recall=recall_score(yte, test_pred, zero_division=0),
            f1=f1_score(yte, test_pred, zero_division=0),
            balanced_accuracy=balanced_accuracy_score(yte, test_pred),
            specificity=specificity,
            auc_roc=auc,
            n_parametros_stub=n_params,
            train_time_s=round(train_time, 4),
            infer_time_per_image_s=round(infer_time_per_img, 6),
            val_accuracy=accuracy_score(yval, val_pred) if len(yval) else None,
        )
        resultados.append(metrics)
        predicciones_finales[f"{arch_name}_seed{seed}"] = list(zip(
            ids_te.tolist(), yte.tolist(), test_pred.tolist(), test_proba.tolist()))

        cfg_path = f"{EVID}/config_{arch_name}_seed{seed}.json"
        with open(cfg_path, "w") as f:
            json.dump({
                "arquitectura_stub": arch_name,
                "modelo_real_equivalente": "ResNet-50 (ImageNet, fine-tuning)" if "ResNet" in arch_name else "VGG-16 (ImageNet, fine-tuning)",
                "seed": seed, "input_size_piloto": IMG_SIZE, "input_size_real": [224, 224, 3],
                "n_train": len(Xtr), "n_val": len(Xval), "n_test": len(Xte),
                "n_parametros_stub": n_params,
                "metrics_test": metrics,
            }, f, indent=2, ensure_ascii=False)

resultados_df = pd.DataFrame(resultados)
resultados_df.to_csv(f"{EVID}/metrics_summary_automatizado.csv", index=False)

# Predicciones finales — formato EXACTO de P09 del protocolo: image_id, true_class,
# predicted_class, model, seed, probabilidad
for key, preds in predicciones_finales.items():
    arch_name, seed_str = key.rsplit("_seed", 1)
    with open(f"{EVID}/predictions_{key}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["image_id", "true_class", "predicted_class", "model", "seed", "probability_conforme"])
        for iid, t, p, proba in preds:
            w.writerow([iid, t, p, arch_name, seed_str, round(proba, 4)])

print("\n[ENTRENAMIENTO-REDUCIDO] Resultados por arquitectura-stub y semilla (incluye AUC-ROC, Specificity):")
print(resultados_df.to_string(index=False))

with open(f"{EVID}/resumen_entrenamiento.json", "w") as f:
    json.dump({
        "n_train": int(len(Xtr)), "n_val": int(len(Xval)), "n_test": int(len(Xte)),
        "seeds_usadas_piloto": SEEDS, "seeds_reales_protocolo": [10, 20, 30, 40, 50],
        "resultados": resultados_df.to_dict(orient="records"),
    }, f, indent=2, ensure_ascii=False)
