"""
PILOTO - Paso 5: P08 (linea base manual) + P11 (analisis estadistico) + P12 (analisis de errores) - v2
---------------------------------------------------------------------------------------------------------
CORRECCION DE ALINEACION: la v1 no calculaba el TAMANO DE EFECTO (odds ratio)
que exige el protocolo (seccion 2.12) para McNemar, ni aplicaba correccion
por comparaciones multiples al existir 3 condiciones (manual, stub_ResNet50,
stub_VGG16). Esta v2 agrega ambas cosas.

*** SUSTITUTO TEMPORAL ***
No es posible, dentro de este entorno de piloto, que el investigador revise
fisicamente las fotografias y cronometre el tiempo real. Por eso el "tiempo de
revision manual" y la "decision manual" de este script son SIMULADOS con una
funcion aleatoria acotada a valores plausibles (ver literatura: ~20-30 s por
imagen). El OBJETIVO de este paso no es medir el desempeno real del metodo
manual, sino comprobar que el CODIGO de comparacion estadistica (McNemar +
odds ratio, Shapiro-Wilk, prueba t/Wilcoxon, correccion multiple) funciona
correctamente. En la ejecucion real, `manual_eval.csv` se completa con el
tiempo y la decision REAL del investigador, cronometrados uno por uno.
"""
import json, csv
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.contingency_tables import mcnemar
from statsmodels.stats.multitest import multipletests

EVID = "/home/claude/piloto/evidencias"
rng = np.random.RandomState(7)

df_split = pd.read_csv(f"{EVID}/dataset_split.csv")
test_df = df_split[df_split["split"] == "test"].reset_index(drop=True)
n_test = len(test_df)

# ---------- P08 SIMULADO: revision manual (un unico revisor: el investigador) ----------
manual_rows = []
for _, row in test_df.iterrows():
    t = max(5, rng.normal(loc=26, scale=6))  # tiempo simulado ~N(26s, 6s), truncado a >=5s
    error_manual = rng.rand() < 0.08  # 8% de probabilidad de error humano simulado
    true_label = 1 if row["etiqueta_sunedu"] == "Conforme" else 0
    manual_pred = true_label if not error_manual else 1 - true_label
    manual_rows.append(dict(image_id=row["id_imagen"], true_class=true_label,
                             manual_pred=manual_pred, tiempo_seg=round(t, 2)))

manual_df = pd.DataFrame(manual_rows)
manual_df.to_csv(f"{EVID}/manual_eval_SIMULADO.csv", index=False)
print(f"[MANUAL-SIMULADO] {n_test} imagenes 'revisadas'. Tiempo promedio simulado: {manual_df['tiempo_seg'].mean():.2f} s")

# ---------- Cargar las 2 arquitecturas-stub (seed 10 cada una) ----------
auto_resnet = pd.read_csv(f"{EVID}/predictions_stub_ResNet50_seed10.csv")
auto_vgg = pd.read_csv(f"{EVID}/predictions_stub_VGG16_seed10.csv")

resumen_train = json.load(open(f"{EVID}/resumen_entrenamiento.json"))
def infer_time_de(arch, seed):
    return next(r["infer_time_per_image_s"] for r in resumen_train["resultados"]
                if r["arch"] == arch and r["seed"] == seed)

def merge_con_manual(auto_df, arch_name):
    m = manual_df.merge(auto_df, on=["image_id", "true_class"], how="inner")
    m["tiempo_auto_seg"] = infer_time_de(arch_name, 10)
    return m

merged_resnet = merge_con_manual(auto_resnet, "stub_ResNet50")
merged_vgg = merge_con_manual(auto_vgg, "stub_VGG16")
# tabla cruzada ResNet-stub vs VGG-stub (ambas contra el mismo ground truth)
merged_rv = auto_resnet.merge(auto_vgg, on=["image_id", "true_class"], suffixes=("_resnet", "_vgg"))

def mcnemar_con_odds_ratio(correct_a, correct_b):
    """McNemar + odds ratio como tamano de efecto (protocolo, seccion 2.12).
    b = A acierta y B falla; c = A falla y B acierta. OR = b/c (con +0.5 si c=0,
    correccion de Haldane-Anscombe para evitar division por cero)."""
    tabla = pd.crosstab(correct_a, correct_b)
    for i in [0, 1]:
        if i not in tabla.index: tabla.loc[i] = [0, 0]
        if i not in tabla.columns: tabla[i] = 0
    tabla = tabla.sort_index()[sorted(tabla.columns)]
    b = tabla.loc[1, 0] if (1 in tabla.index and 0 in tabla.columns) else 0  # A acierta, B falla
    c = tabla.loc[0, 1] if (0 in tabla.index and 1 in tabla.columns) else 0  # A falla, B acierta
    b_adj, c_adj = (b + 0.5, c + 0.5) if (b == 0 or c == 0) else (b, c)
    odds_ratio = b_adj / c_adj
    res = mcnemar(tabla.values, exact=(tabla.values.sum() < 25))
    return tabla, float(res.statistic), float(res.pvalue), float(odds_ratio)

# ---------- P11: 3 comparaciones pareadas (manual vs ResNet-stub, manual vs VGG-stub, ResNet-stub vs VGG-stub) ----------
manual_correct = (merged_resnet["manual_pred"] == merged_resnet["true_class"]).astype(int)
resnet_correct = (merged_resnet["predicted_class"] == merged_resnet["true_class"]).astype(int)
vgg_correct = (merged_vgg["predicted_class"] == merged_vgg["true_class"]).astype(int)
resnet_correct_rv = (merged_rv["predicted_class_resnet"] == merged_rv["true_class"]).astype(int)
vgg_correct_rv = (merged_rv["predicted_class_vgg"] == merged_rv["true_class"]).astype(int)

tabla1, stat1, p1, or1 = mcnemar_con_odds_ratio(manual_correct, resnet_correct)
tabla2, stat2, p2, or2 = mcnemar_con_odds_ratio(manual_correct, vgg_correct)
tabla3, stat3, p3, or3 = mcnemar_con_odds_ratio(resnet_correct_rv, vgg_correct_rv)

comparaciones = ["manual_vs_stubResNet50", "manual_vs_stubVGG16", "stubResNet50_vs_stubVGG16"]
pvalues = [p1, p2, p3]
odds_ratios = [or1, or2, or3]
statistics_ = [stat1, stat2, stat3]

# ---------- Correccion por comparaciones multiples (Holm-Bonferroni, >2 condiciones) ----------
reject, pvals_corr, _, _ = multipletests(pvalues, alpha=0.05, method="holm")

print("\n[MCNEMAR + ODDS RATIO] (3 comparaciones pareadas, correccion Holm-Bonferroni)")
for comp, stat, p, orr, p_corr, rej in zip(comparaciones, statistics_, pvalues, odds_ratios, pvals_corr, reject):
    print(f"  {comp}: estadistico={stat:.3f} | p={p:.4f} | odds_ratio={orr:.3f} | p_corregido={p_corr:.4f} | significativo(a=.05)={rej}")

# ---------- Shapiro-Wilk + prueba de tiempos (manual vs automatizado, usando VGG-stub como referencia) ----------
shapiro_manual = stats.shapiro(merged_vgg["tiempo_seg"])
print(f"\n[SHAPIRO-WILK] tiempos manuales: W={shapiro_manual.statistic:.4f}, p={shapiro_manual.pvalue:.4f}")

if shapiro_manual.pvalue > 0.05 and merged_vgg["tiempo_auto_seg"].nunique() > 1:
    ttest = stats.ttest_ind(merged_vgg["tiempo_seg"], merged_vgg["tiempo_auto_seg"], equal_var=False)
    time_test_name, time_stat, time_p = "t de Student (Welch)", ttest.statistic, ttest.pvalue
else:
    try:
        wtest = stats.wilcoxon(merged_vgg["tiempo_seg"], merged_vgg["tiempo_auto_seg"])
        time_test_name, time_stat, time_p = "Wilcoxon", wtest.statistic, wtest.pvalue
    except ValueError:
        time_test_name, time_stat, time_p = "Wilcoxon (no aplicable: varianza cero)", float("nan"), float("nan")

print(f"[TIEMPOS] Prueba usada: {time_test_name} | estadistico={time_stat} | p={time_p}")

reduccion_pct = 100 * (1 - merged_vgg["tiempo_auto_seg"].mean() / merged_vgg["tiempo_seg"].mean())
print(f"[TIEMPOS] Reduccion de tiempo promedio (simulado): {reduccion_pct:.2f}%")

# ---------- P12: Analisis de errores por criterio incumplido (stub_VGG16 como referencia) ----------
meta = pd.read_csv(f"{EVID}/dataset_metadata.csv")
merged2 = merged_vgg.merge(meta[["id_imagen", "criterios_incumplidos"]], left_on="image_id", right_on="id_imagen", how="left")
merged2["error_automatizado"] = merged2["predicted_class"] != merged2["true_class"]
errores_por_criterio = merged2[merged2["error_automatizado"]]["criterios_incumplidos"].value_counts()
n_falsos_negativos = int(((merged2["error_automatizado"]) & (merged2["true_class"] == 1)).sum())
n_falsos_positivos = int(((merged2["error_automatizado"]) & (merged2["true_class"] == 0)).sum())
print(f"\n[ANALISIS-ERRORES] Errores del automatizado (stub_VGG16): {n_falsos_negativos} falsos negativos (Conforme->No conforme), {n_falsos_positivos} falsos positivos (No conforme->Conforme)")
if errores_por_criterio.empty:
    print("[ANALISIS-ERRORES] Sin desglose por criterio: todos los errores son falsos negativos (imagenes realmente Conforme, sin 'criterios_incumplidos'); el desglose por criterio solo aplica a falsos positivos, que no ocurrieron en este piloto reducido (el stub predice mayoritariamente la clase 'No conforme').")
else:
    print(errores_por_criterio)

resultado_estadistico = {
    "n_test_comparado": int(len(merged_vgg)),
    "comparaciones_pareadas": [
        {"comparacion": comp, "estadistico_mcnemar": stat, "p_value": p, "odds_ratio": orr,
         "p_value_corregido_holm": float(p_corr), "significativo_alpha_0.05": bool(rej)}
        for comp, stat, p, orr, p_corr, rej in zip(comparaciones, statistics_, pvalues, odds_ratios, pvals_corr, reject)
    ],
    "shapiro_wilk_tiempos_manual": {"W": float(shapiro_manual.statistic), "p_value": float(shapiro_manual.pvalue)},
    "prueba_tiempos": {"nombre": time_test_name, "estadistico": float(time_stat) if time_stat == time_stat else None, "p_value": float(time_p) if time_p == time_p else None},
    "reduccion_tiempo_pct_simulado": float(reduccion_pct),
    "errores_automatizado_por_criterio": errores_por_criterio.to_dict(),
    "falsos_negativos": n_falsos_negativos, "falsos_positivos": n_falsos_positivos,
    "advertencia": "Datos de tiempo/decision MANUAL simulados. No representan evidencia cientifica; solo validan el codigo estadistico (incluye ahora odds ratio y correccion Holm-Bonferroni)."
}
with open(f"{EVID}/resultado_analisis_estadistico.json", "w") as f:
    json.dump(resultado_estadistico, f, indent=2, ensure_ascii=False)

merged2.to_csv(f"{EVID}/comparacion_manual_vs_automatizado.csv", index=False)
