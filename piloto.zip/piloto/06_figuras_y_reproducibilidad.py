import json, os, sys, platform
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import numpy as np

EVID = "/home/claude/piloto/evidencias"
FIG = "/home/claude/piloto/figuras"
os.makedirs(FIG, exist_ok=True)

# ---------- Figura 1: matriz de confusion (stub_VGG16 seed 10, test) ----------
pred = pd.read_csv(f"{EVID}/predictions_stub_VGG16_seed10.csv")
cm = confusion_matrix(pred["true_class"], pred["predicted_class"], labels=[0, 1])
fig, ax = plt.subplots(figsize=(4, 4))
im = ax.imshow(cm, cmap="Blues")
for i in range(2):
    for j in range(2):
        ax.text(j, i, cm[i, j], ha="center", va="center", color="black", fontsize=14)
ax.set_xticks([0, 1]); ax.set_xticklabels(["No conforme", "Conforme"])
ax.set_yticks([0, 1]); ax.set_yticklabels(["No conforme", "Conforme"])
ax.set_xlabel("Predicho"); ax.set_ylabel("Real")
ax.set_title("Matriz de confusion - stub_VGG16 (seed 10, test piloto)")
plt.tight_layout()
plt.savefig(f"{FIG}/matriz_confusion_stubVGG16.png", dpi=140)
plt.close()

# ---------- Figura 2: comparacion de metricas por arquitectura-stub (incluye AUC-ROC y Specificity) ----------
metrics_df = pd.read_csv(f"{EVID}/metrics_summary_automatizado.csv")
agg = metrics_df.groupby("arch")[["accuracy", "f1", "balanced_accuracy", "specificity", "auc_roc"]].mean()
fig, ax = plt.subplots(figsize=(7, 4))
agg.plot(kind="bar", ax=ax)
ax.set_ylim(0, 1)
ax.set_ylabel("Valor de la metrica")
ax.set_title("Metricas promedio por arquitectura-stub (piloto, 2 semillas)")
plt.xticks(rotation=0)
plt.legend(loc="lower right", fontsize=8)
plt.tight_layout()
plt.savefig(f"{FIG}/metricas_por_arquitectura.png", dpi=140)
plt.close()

# ---------- Figura 2b: odds ratio de las 3 comparaciones pareadas (McNemar) ----------
resultado_stats = json.load(open(f"{EVID}/resultado_analisis_estadistico.json"))
comps = resultado_stats["comparaciones_pareadas"]
fig, ax = plt.subplots(figsize=(6, 4))
nombres = [c["comparacion"].replace("_", "\n") for c in comps]
ors = [c["odds_ratio"] for c in comps]
colors = ["#2471a3" if not c["significativo_alpha_0.05"] else "#c0392b" for c in comps]
ax.bar(nombres, ors, color=colors)
ax.axhline(1.0, color="gray", linestyle="--", linewidth=1)
ax.set_ylabel("Odds ratio (McNemar)")
ax.set_title("Tamano de efecto por comparacion (rojo = significativo tras Holm-Bonferroni)")
plt.tight_layout()
plt.savefig(f"{FIG}/odds_ratio_comparaciones.png", dpi=140)
plt.close()

# ---------- Figura 3: tiempo manual (simulado) vs automatizado ----------
comp = pd.read_csv(f"{EVID}/comparacion_manual_vs_automatizado.csv")
fig, ax = plt.subplots(figsize=(5, 4))
ax.bar(["Manual (simulado)", "Automatizado (stub)"],
       [comp["tiempo_seg"].mean(), comp["tiempo_auto_seg"].mean()],
       color=["#c0392b", "#2471a3"])
ax.set_ylabel("Tiempo promedio por imagen (s)")
ax.set_title("Tiempo de validacion: manual (simulado) vs automatizado")
for i, v in enumerate([comp["tiempo_seg"].mean(), comp["tiempo_auto_seg"].mean()]):
    ax.text(i, v, f"{v:.3f}s", ha="center", va="bottom")
plt.tight_layout()
plt.savefig(f"{FIG}/tiempo_manual_vs_automatizado.png", dpi=140)
plt.close()

print("[FIGURAS] Generadas: matriz_confusion_stubVGG16.png, metricas_por_arquitectura.png, odds_ratio_comparaciones.png, tiempo_manual_vs_automatizado.png")

# ---------- Reproducibilidad: requirements + entorno + README ----------
import sklearn, scipy, PIL, cv2, statsmodels
env_info = {
    "python_version": sys.version,
    "plataforma": platform.platform(),
    "librerias": {
        "numpy": np.__version__, "pandas": pd.__version__, "scikit-learn": sklearn.__version__,
        "scipy": scipy.__version__, "pillow": PIL.__version__, "opencv-python": cv2.__version__,
        "statsmodels": statsmodels.__version__, "matplotlib": matplotlib.__version__,
    },
    "semillas_utilizadas": {"generacion_dataset": 42, "particion": 42, "entrenamiento_piloto": [10, 20], "manual_simulado": 7},
}
with open(f"{EVID}/entorno_reproducibilidad.json", "w") as f:
    json.dump(env_info, f, indent=2, ensure_ascii=False)

print("[REPRODUCIBILIDAD] entorno_reproducibilidad.json guardado.")
