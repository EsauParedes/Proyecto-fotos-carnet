"""
PILOTO CON FOTOGRAFIAS REALES - Paso 7 (complementario a P01-P02)
--------------------------------------------------------------------
A diferencia de 01_generar_dataset.py (datos 100% sinteticos), este script
procesa 15 FOTOGRAFIAS REALES de un mismo estudiante (el autor de la tesis),
para probar el pipeline de auditoria y de CORRECCION TECNICA automatica
contra los parametros OFICIALES del validador de SUNEDU.

IMPORTANTE - alcance de esta prueba:
- Las 15 fotos son de la MISMA persona => mismo group_id. Por protocolo
  (seccion 2.4, P03), TODAS deben permanecer en la MISMA particion; con una
  sola persona no es posible ni correcto simular aqui una particion
  train/val/test real (se necesitan ~700+ estudiantes distintos para eso).
  Esta prueba se limita a P01/P02 (registro, auditoria, correccion tecnica),
  que SI son representativos con una sola persona.
- La etiqueta Conforme/No conforme real debe emitirla el validador oficial
  de SUNEDU (https://siucarne.sunedu.gob.pe/carne/validacion); este script
  usa el MISMO validador_sunedu_SIMULADO() de 02_auditoria.py como
  aproximacion, ya que no se puede invocar el sitio real desde este entorno.
"""
import os, json, csv, time
import numpy as np
import cv2
from PIL import Image


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    raise TypeError(f"Object of type {type(o)} is not JSON serializable")

RAW_DIR = "/home/claude/piloto/data_real_original"
OUT_DIR = "/home/claude/piloto/data_real_corregida"
EVID_DIR = "/home/claude/piloto/evidencias_real"
os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(EVID_DIR, exist_ok=True)

# ---------- Parametros oficiales de SUNEDU (identicos a 02_auditoria.py) ----------
RANGO_TAMANO_KB = (4, 50)
RANGO_ANCHO_PX = (240, 240)
RANGO_ALTO_PX = (288, 288)
RANGO_DPI = (300, 300)
RANGO_RGB_FONDO = (220, 255)
RANGO_OJO_IZQ_X, RANGO_OJO_IZQ_Y = (24, 120), (55, 180)
RANGO_OJO_DER_X, RANGO_OJO_DER_Y = (80, 185), (50, 180)
RANGO_BOCA_X, RANGO_BOCA_Y = (50, 161), (70, 252)

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
eye_cascade_glasses = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye_tree_eyeglasses.xml")
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")
smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_smile.xml")

from rembg import remove, new_session
REMBG_SESSION = new_session("u2netp")


def detectar_rostro(gray):
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=6, minSize=(80, 80))
    if len(faces) == 0:
        return None
    # tomar el rostro mas grande (mas cercano a la camara / mejor encuadrado)
    return max(faces, key=lambda f: f[2] * f[3])


def detectar_ojos_boca_reales(img_bgr, face_box):
    """Detecta ojos (con cascada tolerante a lentes) y boca (via cascada de
    sonrisa, que delimita la region de la boca) DENTRO del area del rostro,
    y devuelve sus coordenadas (x,y) en el sistema de la imagen COMPLETA."""
    fx, fy, fw, fh = face_box
    roi_gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)[fy:fy + fh, fx:fx + fw]

    eyes = eye_cascade_glasses.detectMultiScale(roi_gray, scaleFactor=1.05, minNeighbors=8, minSize=(15, 15))
    if len(eyes) < 2:
        eyes = eye_cascade.detectMultiScale(roi_gray, scaleFactor=1.05, minNeighbors=8, minSize=(15, 15))
    eyes = [e for e in eyes if e[1] < fh * 0.6]  # descartar falsos positivos bajos (boca, mejillas)
    eyes = sorted(eyes, key=lambda e: e[0])[:2]

    if len(eyes) == 2:
        (ex1, ey1, ew1, eh1), (ex2, ey2, ew2, eh2) = eyes
        ojo_izq = (fx + ex1 + ew1 / 2, fy + ey1 + eh1 / 2)
        ojo_der = (fx + ex2 + ew2 / 2, fy + ey2 + eh2 / 2)
    else:
        ojo_izq = ojo_der = (None, None)

    boca_roi = roi_gray[int(fh * 0.55):, :]
    smiles = smile_cascade.detectMultiScale(boca_roi, scaleFactor=1.4, minNeighbors=20, minSize=(25, 15))
    if len(smiles) > 0:
        sx, sy, sw, sh = max(smiles, key=lambda s: s[2] * s[3])
        boca = (fx + sx + sw / 2, fy + int(fh * 0.55) + sy + sh / 2)
    elif ojo_izq[0] is not None and ojo_der[0] is not None:
        # Fallback GEOMETRICO (no requiere sonrisa): proporciones antropometricas
        # estandar -- la boca se ubica, en promedio, centrada horizontalmente
        # entre los ojos y ~1.15x la distancia interocular por debajo de la
        # linea de los ojos. Mas robusto que la cascada de sonrisa para fotos
        # de expresion neutra (la mayoria de fotos de carnet).
        dist_ojos = abs(ojo_der[0] - ojo_izq[0])
        boca_x = (ojo_izq[0] + ojo_der[0]) / 2
        boca_y = (ojo_izq[1] + ojo_der[1]) / 2 + 1.15 * dist_ojos
        boca = (boca_x, boca_y)
    else:
        boca = (None, None)

    return ojo_izq, ojo_der, boca


def en_rango(valor, rango):
    return valor is not None and rango[0] <= valor <= rango[1]


def validador_sunedu_SIMULADO(width, height, dpi, tamano_kb, rgb_fondo, ojo_izq, ojo_der, boca, cumple_formato):
    fallos = []
    if (width, height) != RANGO_ANCHO_PX + RANGO_ALTO_PX and not (width == 240 and height == 288):
        fallos.append("dimension_incorrecta")
    if dpi is None or not (RANGO_DPI[0] <= round(dpi) <= RANGO_DPI[1]):
        fallos.append("resolucion_dpi_incorrecta")
    if not (RANGO_TAMANO_KB[0] <= tamano_kb <= RANGO_TAMANO_KB[1]):
        fallos.append("tamano_archivo_fuera_de_rango")
    r, g, b = rgb_fondo
    if not all(RANGO_RGB_FONDO[0] <= c <= RANGO_RGB_FONDO[1] for c in (r, g, b)):
        fallos.append("fondo_no_blanco")
    if not (en_rango(ojo_izq[0], RANGO_OJO_IZQ_X) and en_rango(ojo_izq[1], RANGO_OJO_IZQ_Y)):
        fallos.append("ojo_izquierdo_fuera_de_posicion")
    if not (en_rango(ojo_der[0], RANGO_OJO_DER_X) and en_rango(ojo_der[1], RANGO_OJO_DER_Y)):
        fallos.append("ojo_derecho_fuera_de_posicion")
    if not (en_rango(boca[0], RANGO_BOCA_X) and en_rango(boca[1], RANGO_BOCA_Y)):
        fallos.append("boca_fuera_de_posicion")
    if not cumple_formato:
        fallos.append("formato_invalido")
    return len(fallos) == 0, fallos


def fondo_rgb_promedio(img_rgb):
    """Muestrea SOLO los bordes superior, izquierdo y derecho. El borde
    INFERIOR de una foto de carnet correctamente encuadrada ('desde los
    hombros') muestra prendas de vestir, no fondo -- incluirlo en la
    muestra de 'fondo blanco' seria un error de medicion, no del fondo real."""
    arr = np.array(img_rgb)
    h, w = arr.shape[:2]
    border = np.concatenate([
        arr[0:int(h * 0.06), :, :3].reshape(-1, 3),
        arr[int(h * 0.10):int(h * 0.55), 0:int(w * 0.06), :3].reshape(-1, 3),
        arr[int(h * 0.10):int(h * 0.55), -int(w * 0.06):, :3].reshape(-1, 3),
    ])
    return border[:, 0].mean(), border[:, 1].mean(), border[:, 2].mean()


def auditar(path):
    """Audita una imagen tal cual esta (sin corregir)."""
    size_kb = os.path.getsize(path) / 1024
    img_pil = Image.open(path).convert("RGB")
    width, height = img_pil.size
    dpi = img_pil.info.get("dpi", (None, None))[0]
    cumple_formato = path.lower().endswith((".jpg", ".jpeg"))
    img_bgr = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    face = detectar_rostro(gray)
    if face is None:
        ojo_izq, ojo_der, boca = (None, None), (None, None), (None, None)
    else:
        ojo_izq, ojo_der, boca = detectar_ojos_boca_reales(img_bgr, face)
    rgb_bg = fondo_rgb_promedio(img_pil)
    conforme, fallos = validador_sunedu_SIMULADO(width, height, dpi, size_kb, rgb_bg, ojo_izq, ojo_der, boca, cumple_formato)
    return dict(width=width, height=height, dpi=dpi, tamano_kb=round(size_kb, 1),
                bg_r=round(rgb_bg[0], 1), bg_g=round(rgb_bg[1], 1), bg_b=round(rgb_bg[2], 1),
                rostro_detectado=face is not None,
                ojo_izq_x=ojo_izq[0], ojo_izq_y=ojo_izq[1], ojo_der_x=ojo_der[0], ojo_der_y=ojo_der[1],
                boca_x=boca[0], boca_y=boca[1],
                etiqueta_sunedu="Conforme" if conforme else "No conforme",
                criterios_incumplidos=";".join(fallos))


def corregir(path, out_path):
    """Corrige automaticamente lo que es corregible por software:
    fondo (rembg -> blanco), encuadre (crop centrado en el rostro),
    dimension (240x288), resolucion (300 dpi) y tamano (4-50 KB)."""
    img_pil = Image.open(path).convert("RGB")
    img_bgr = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    face = detectar_rostro(gray)

    # 1) Remover fondo y componer sobre blanco puro
    sin_fondo = remove(img_pil, session=REMBG_SESSION)  # RGBA
    alpha_full = np.array(sin_fondo)[:, :, 3]
    w0, h0 = sin_fondo.size

    blanco = Image.new("RGBA", sin_fondo.size, (255, 255, 255, 255))
    compuesta = Image.alpha_composite(blanco, sin_fondo).convert("RGB")

    # 2) Encuadre: recorte centrado en el rostro, con proporcion 240:288 y
    #    espacio para hombros (criterio: "desde los hombros, sin medio cuerpo")
    if face is not None:
        fx, fy, fw, fh = face
        crop_h = fh / 0.50          # el rostro ocupara ~50% del alto del recorte
        crop_w = crop_h * (240 / 288)
        cx = fx + fw / 2
        top = fy - crop_h * 0.25    # margen superior (cabello)
        left = cx - crop_w / 2
    else:
        # sin rostro detectado: recorte centrado generico
        crop_h = h0
        crop_w = crop_h * (240 / 288)
        left = (w0 - crop_w) / 2
        top = 0

    left = max(0, min(left, w0 - crop_w))
    top = max(0, min(top, h0 - crop_h))
    right = min(w0, left + crop_w)
    bottom = min(h0, top + crop_h)

    # Verificar margen DENTRO de la region que realmente se va a recortar (no
    # en la imagen completa): si las franjas verticales izquierda/derecha del
    # recorte ya estan ocupadas por la persona, no hay fondo que mostrar y la
    # correccion de color de fondo no sera suficiente.
    alpha_crop = alpha_full[int(top):int(bottom), int(left):int(right)]
    ch, cw = alpha_crop.shape
    franja = max(1, int(cw * 0.06))
    ocupacion_bordes = ((alpha_crop[:, :franja] > 128).mean() + (alpha_crop[:, -franja:] > 128).mean()) / 2
    margen_disponible = bool(ocupacion_bordes < 0.5)

    recorte = compuesta.crop((int(left), int(top), int(right), int(bottom)))
    recorte = recorte.resize((240, 288), Image.LANCZOS)

    # 3) Guardar como JPG, 300 dpi, ajustando calidad para caer en 4-50 KB
    for quality in [85, 75, 65, 55, 45, 35, 28]:
        recorte.save(out_path, "JPEG", quality=quality, dpi=(300, 300))
        kb = os.path.getsize(out_path) / 1024
        if kb <= 50:
            break
    return recorte, face is not None, margen_disponible


# =====================================================================
files = sorted(os.listdir(RAW_DIR))
resultados_antes = {}
resultados_despues = {}

print(f"[FOTOS-REALES] Procesando {len(files)} fotografias reales del mismo estudiante (group_id unico)...")
for fname in files:
    path = os.path.join(RAW_DIR, fname)
    t0 = time.time()
    antes = auditar(path)
    resultados_antes[fname] = antes

    out_name = os.path.splitext(fname)[0] + "_corregida.jpg"
    out_path = os.path.join(OUT_DIR, out_name)
    try:
        _, rostro_ok, margen_ok = corregir(path, out_path)
        despues = auditar(out_path)
        despues["rostro_detectado_para_recorte"] = bool(rostro_ok)
        despues["margen_de_fondo_disponible_en_original"] = margen_ok
        if not margen_ok:
            despues["criterios_incumplidos"] = (despues.get("criterios_incumplidos", "") +
                ";NO_CORREGIBLE_sin_margen_de_fondo_en_foto_original").strip(";")
    except Exception as e:
        despues = {"error": f"{type(e).__name__}: {e}"}
    resultados_despues[fname] = despues
    dt = time.time() - t0
    margen_txt = "" if despues.get("margen_de_fondo_disponible_en_original", True) else " [SIN MARGEN DE FONDO]"
    print(f"  {fname}: antes={antes['etiqueta_sunedu']} ({antes['criterios_incumplidos']}) "
          f"-> despues={despues.get('etiqueta_sunedu','ERROR')} ({despues.get('criterios_incumplidos','')}){margen_txt} [{dt:.1f}s]")

# ---------- Guardar evidencias ----------
with open(f"{EVID_DIR}/auditoria_antes.json", "w") as f:
    json.dump(resultados_antes, f, indent=2, ensure_ascii=False, default=_json_default)
with open(f"{EVID_DIR}/auditoria_despues_correccion.json", "w") as f:
    json.dump(resultados_despues, f, indent=2, ensure_ascii=False, default=_json_default)

n_conforme_antes = sum(1 for r in resultados_antes.values() if r.get("etiqueta_sunedu") == "Conforme")
n_conforme_despues = sum(1 for r in resultados_despues.values() if r.get("etiqueta_sunedu") == "Conforme")
print(f"\n[FOTOS-REALES] Conformes ANTES de corregir: {n_conforme_antes}/{len(files)}")
print(f"[FOTOS-REALES] Conformes DESPUES de corregir: {n_conforme_despues}/{len(files)}")

resumen = dict(
    total_fotos=len(files), group_id="ESAU_PAREDES (mismo estudiante en las 15 fotos)",
    n_conforme_antes=n_conforme_antes, n_conforme_despues=n_conforme_despues,
    nota="Por tener un unico group_id, estas 15 fotos NO pueden (ni deben) repartirse en particiones train/val/test distintas; todas permanecen juntas, conforme al protocolo V1.3, seccion 2.4.",
)
with open(f"{EVID_DIR}/resumen_fotos_reales.json", "w") as f:
    json.dump(resumen, f, indent=2, ensure_ascii=False, default=_json_default)
