"""
PILOTO CON BASE DE DATOS REAL "Ft" - Paso 1: P01 (registro) + P02 (auditoria)
-------------------------------------------------------------------------------
Dataset: 72 fotografias reales (una por estudiante), ya en formato 240x288,
300 dpi, 4-50 KB -- es decir, YA pasaron el formato basico. Se auditan los
8 criterios OFICIALES de SUNEDU usando deteccion real de rostro/ojos/boca
(OpenCV Haar Cascade, igual que en 07_fotos_reales.py).

HALLAZGO DEL PILOTO: al auditar las 72 fotos tal cual, 68 resultan Conforme
y solo 4 No conforme (94%/6%) -- muy lejos del balance 50/50 asumido en el
protocolo (seccion 1.7). Esto es consistente con que el protocolo YA preve
esta situacion (seccion 2.5): "se generaran versiones degradadas... de
imagenes originalmente conformes para ampliar la casuistica de la clase
No conforme". Este script aplica exactamente esa tecnica: cada fotografia
Conforme recibe UNA copia degradada (mismo group_id = mismo estudiante,
mismo codigo de 8 digitos), con un defecto realista elegido aleatoriamente
(dpi bajo, encuadre descentrado, o fondo con tinte de color), para balancear
el dataset sin alterar las fotos de los 4 estudiantes ya naturalmente no
conformes.
"""
import os, json, csv, random
import numpy as np
import cv2
from PIL import Image, ImageEnhance

random.seed(42)
np.random.seed(42)

RAW_DIR = "/home/claude/piloto/data_Ft_raw"
PROC_DIR = "/home/claude/piloto/data_Ft_procesado"
EVID_DIR = "/home/claude/piloto/evidencias_Ft"
os.makedirs(PROC_DIR, exist_ok=True)
os.makedirs(EVID_DIR, exist_ok=True)

RANGO_TAMANO_KB = (4, 50)
RANGO_DPI = (300, 300)
RANGO_RGB_FONDO = (220, 255)
RANGO_OJO_IZQ_X, RANGO_OJO_IZQ_Y = (24, 120), (55, 180)
RANGO_OJO_DER_X, RANGO_OJO_DER_Y = (80, 185), (50, 180)
RANGO_BOCA_X, RANGO_BOCA_Y = (50, 161), (70, 252)

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
eye_cascade_glasses = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye_tree_eyeglasses.xml")
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")


def _j(o):
    if isinstance(o, (np.integer,)): return int(o)
    if isinstance(o, (np.floating,)): return float(o)
    if isinstance(o, (np.bool_,)): return bool(o)
    raise TypeError(str(type(o)))


def detectar_rostro(gray):
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=6, minSize=(80, 80))
    if len(faces) == 0:
        return None
    return max(faces, key=lambda f: f[2] * f[3])


def detectar_ojos_boca(img_bgr, face_box):
    fx, fy, fw, fh = face_box
    roi_gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)[fy:fy + fh, fx:fx + fw]
    eyes = eye_cascade_glasses.detectMultiScale(roi_gray, scaleFactor=1.05, minNeighbors=8, minSize=(15, 15))
    if len(eyes) < 2:
        eyes = eye_cascade.detectMultiScale(roi_gray, scaleFactor=1.05, minNeighbors=8, minSize=(15, 15))
    eyes = [e for e in eyes if e[1] < fh * 0.6]
    eyes = sorted(eyes, key=lambda e: e[0])[:2]
    if len(eyes) == 2:
        (ex1, ey1, ew1, eh1), (ex2, ey2, ew2, eh2) = eyes
        ojo_izq = (fx + ex1 + ew1 / 2, fy + ey1 + eh1 / 2)
        ojo_der = (fx + ex2 + ew2 / 2, fy + ey2 + eh2 / 2)
    else:
        ojo_izq = ojo_der = (None, None)
    if ojo_izq[0] is not None:
        dist = abs(ojo_der[0] - ojo_izq[0])
        boca = ((ojo_izq[0] + ojo_der[0]) / 2, (ojo_izq[1] + ojo_der[1]) / 2 + 1.15 * dist)
    else:
        boca = (None, None)
    return ojo_izq, ojo_der, boca


def en_rango(v, r):
    return v is not None and r[0] <= v <= r[1]


def fondo_rgb(img_rgb):
    arr = np.array(img_rgb); h, w = arr.shape[:2]
    border = np.concatenate([
        arr[0:int(h * 0.06), :, :3].reshape(-1, 3),
        arr[int(h * 0.10):int(h * 0.55), 0:int(w * 0.06), :3].reshape(-1, 3),
        arr[int(h * 0.10):int(h * 0.55), -int(w * 0.06):, :3].reshape(-1, 3),
    ])
    return border[:, 0].mean(), border[:, 1].mean(), border[:, 2].mean()


def sharpness_laplacian(img_rgb):
    gray = cv2.cvtColor(np.array(img_rgb), cv2.COLOR_RGB2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def auditar_imagen(path):
    size_kb = os.path.getsize(path) / 1024
    img_pil = Image.open(path).convert("RGB")
    width, height = img_pil.size
    dpi = img_pil.info.get("dpi", (None, None))[0]
    img_bgr = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    face = detectar_rostro(gray)
    if face is None:
        ojo_izq, ojo_der, boca = (None, None), (None, None), (None, None)
    else:
        ojo_izq, ojo_der, boca = detectar_ojos_boca(img_bgr, face)
    rgb_bg = fondo_rgb(img_pil)
    sharp = sharpness_laplacian(img_pil)

    fallos = []
    if (width, height) != (240, 288): fallos.append("dimension_incorrecta")
    if dpi is None or round(dpi) != 300: fallos.append("resolucion_dpi_incorrecta")
    if not (RANGO_TAMANO_KB[0] <= size_kb <= RANGO_TAMANO_KB[1]): fallos.append("tamano_archivo_fuera_de_rango")
    if not all(RANGO_RGB_FONDO[0] <= c <= RANGO_RGB_FONDO[1] for c in rgb_bg): fallos.append("fondo_no_blanco")
    if not (en_rango(ojo_izq[0], RANGO_OJO_IZQ_X) and en_rango(ojo_izq[1], RANGO_OJO_IZQ_Y)): fallos.append("ojo_izquierdo_fuera_de_posicion")
    if not (en_rango(ojo_der[0], RANGO_OJO_DER_X) and en_rango(ojo_der[1], RANGO_OJO_DER_Y)): fallos.append("ojo_derecho_fuera_de_posicion")
    if not (en_rango(boca[0], RANGO_BOCA_X) and en_rango(boca[1], RANGO_BOCA_Y)): fallos.append("boca_fuera_de_posicion")

    return dict(ancho_px=width, alto_px=height, resolucion_dpi=dpi, tamano_kb=round(size_kb, 2),
                bg_r=round(rgb_bg[0], 1), bg_g=round(rgb_bg[1], 1), bg_b=round(rgb_bg[2], 1),
                varianza_laplaciano=round(sharp, 1),
                ojo_izq_x=ojo_izq[0], ojo_izq_y=ojo_izq[1], ojo_der_x=ojo_der[0], ojo_der_y=ojo_der[1],
                boca_x=boca[0], boca_y=boca[1], rostro_detectado=face is not None,
                etiqueta_sunedu="Conforme" if len(fallos) == 0 else "No conforme",
                criterios_incumplidos=";".join(fallos))


# =====================================================================
# FASE A: auditar las 72 fotos originales tal cual vienen
# =====================================================================
archivos = sorted(f for f in os.listdir(RAW_DIR) if f.lower().endswith(".jpg"))
registro = []
for fname in archivos:
    codigo = os.path.splitext(fname)[0]  # codigo de 8 digitos = group_id real
    audit = auditar_imagen(os.path.join(RAW_DIR, fname))
    registro.append(dict(id_imagen=codigo, nombre_archivo=fname, group_id=codigo,
                          origen="original", **audit))

n_conforme_natural = sum(1 for r in registro if r["etiqueta_sunedu"] == "Conforme")
print(f"[Ft-AUDITORIA] 72 fotos originales: {n_conforme_natural} Conforme, {72 - n_conforme_natural} No conforme (natural)")

# =====================================================================
# FASE B: degradar una copia de CADA foto naturalmente Conforme (protocolo,
# seccion 2.5) para ampliar la clase No conforme. Defecto elegido al azar
# entre 3 tipos realistas, con semilla fija para reproducibilidad.
# =====================================================================
tipos_defecto = ["dpi_bajo", "descentrado", "fondo_con_tinte"]
conformes = [r for r in registro if r["etiqueta_sunedu"] == "Conforme"]

for r in conformes:
    defecto = random.choice(tipos_defecto)
    src_path = os.path.join(RAW_DIR, r["nombre_archivo"])
    img = Image.open(src_path).convert("RGB")
    new_name = f"{r['id_imagen']}_degradada.jpg"
    dpi_out = (300, 300)

    if defecto == "dpi_bajo":
        dpi_out = (150, 150)
    elif defecto == "descentrado":
        arr = np.array(img)
        shift = int(img.width * 0.26) * random.choice([-1, 1])
        lienzo = np.full_like(arr, 255)
        if shift > 0:
            lienzo[:, shift:, :] = arr[:, :arr.shape[1]-shift, :]
        else:
            lienzo[:, :shift, :] = arr[:, -shift:, :]
        img = Image.fromarray(lienzo)
    elif defecto == "fondo_con_tinte":
        # alpha=0.6 y tintes moderados: garantiza que los 3 canales RGB del
        # fondo queden por debajo de 220 (umbral oficial), a diferencia de la
        # v1 de este script (alpha=0.35) que dejaba el fondo en ~239 (aun
        # "blanco" segun el criterio real) -- bug encontrado y corregido.
        tinte = Image.new("RGB", img.size, random.choice([(150, 165, 180), (165, 150, 180), (180, 165, 150)]))
        img = Image.blend(img, tinte, alpha=0.6)

    out_path = os.path.join(PROC_DIR, new_name)
    img.save(out_path, "JPEG", quality=85, dpi=dpi_out)
    # recomprimir si excede 50KB
    q = 85
    while os.path.getsize(out_path) / 1024 > 50 and q > 20:
        q -= 10
        img.save(out_path, "JPEG", quality=q, dpi=dpi_out)

    audit = auditar_imagen(out_path)
    registro.append(dict(id_imagen=f"{r['id_imagen']}_D", nombre_archivo=new_name, group_id=r["group_id"],
                          origen=f"degradada_{defecto}", **audit))

# Copiar tambien los 72 originales al directorio procesado (para que P03+ lean de una sola carpeta)
for r in registro:
    if r["origen"] == "original":
        src = os.path.join(RAW_DIR, r["nombre_archivo"])
        dst = os.path.join(PROC_DIR, r["nombre_archivo"])
        if not os.path.exists(dst):
            Image.open(src).convert("RGB").save(dst, "JPEG", quality=92, dpi=(300, 300))

n_conforme_final = sum(1 for r in registro if r["etiqueta_sunedu"] == "Conforme")
n_no_conforme_final = len(registro) - n_conforme_final
print(f"[Ft-AUDITORIA] Tras degradacion (protocolo 2.5): {len(registro)} imagenes totales")
print(f"[Ft-AUDITORIA] Conforme: {n_conforme_final} | No conforme: {n_no_conforme_final}  (balance {n_conforme_final/len(registro):.0%}/{n_no_conforme_final/len(registro):.0%})")
print(f"[Ft-AUDITORIA] Grupos (estudiantes) unicos: {len(set(r['group_id'] for r in registro))}")

campos = ["id_imagen", "nombre_archivo", "group_id", "origen", "ancho_px", "alto_px", "resolucion_dpi",
          "tamano_kb", "bg_r", "bg_g", "bg_b", "varianza_laplaciano",
          "ojo_izq_x", "ojo_izq_y", "ojo_der_x", "ojo_der_y", "boca_x", "boca_y",
          "rostro_detectado", "etiqueta_sunedu", "criterios_incumplidos"]
with open(f"{EVID_DIR}/dataset_metadata.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=campos, extrasaction="ignore")
    w.writeheader()
    for r in registro:
        w.writerow(r)

resumen = dict(
    n_fotos_originales=72, n_conforme_natural=n_conforme_natural, n_no_conforme_natural=72-n_conforme_natural,
    n_total_tras_degradacion=len(registro), n_conforme_final=n_conforme_final, n_no_conforme_final=n_no_conforme_final,
    n_grupos_unicos=len(set(r["group_id"] for r in registro)),
    tipos_defecto_aplicados=tipos_defecto,
    nota_metodologica="Degradacion aplicada segun protocolo V1.3 seccion 2.5. Cada foto degradada comparte group_id con su original (mismo estudiante), por lo que ambas deben permanecer en la misma particion (ver 09_Ft_particion.py).",
)
with open(f"{EVID_DIR}/resumen_auditoria_Ft.json", "w") as f:
    json.dump(resumen, f, indent=2, ensure_ascii=False, default=_j)

print("[Ft-AUDITORIA] dataset_metadata.csv guardado con esquema Anexo 3 + group_id real (codigo de 8 digitos).")
