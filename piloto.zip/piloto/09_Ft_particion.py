"""
PILOTO Ft - Paso 2: P03 (particion) con 72 ESTUDIANTES REALES
-----------------------------------------------------------------
A diferencia del piloto sintetico (donde group_id era artificial) y del
piloto de una sola persona (un unico group_id), aqui tenemos 72 group_id
REALES y DISTINTOS (codigos de 8 digitos), de los cuales 68 tienen 2
imagenes (original + degradada) y 4 tienen 1 sola imagen (naturalmente
No conforme). Esta es la primera prueba del piloto que permite una
particion train/val/test genuinamente representativa de multiples personas.
"""
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

EVID = "/home/claude/piloto/evidencias_Ft"

df = pd.read_csv(f"{EVID}/dataset_metadata.csv")
print(f"[Ft-PARTICION] Total imagenes: {len(df)} | Grupos (estudiantes) unicos: {df['group_id'].nunique()}")

def overlap(df_split):
    sets = {s: set(df_split[df_split["split"] == s]["group_id"]) for s in ["train", "val", "test"]}
    return sets["train"] & sets["val"], sets["train"] & sets["test"], sets["val"] & sets["test"]

# ---------- (a) Particion INGENUA (aleatoria simple, ignora group_id) ----------
rng = np.random.RandomState(42)
idx = df.index.values.copy()
rng.shuffle(idx)
n = len(idx); n_train = int(n * 0.70); n_val = int(n * 0.15)
split_naive = pd.Series(index=idx, dtype=object)
split_naive.loc[idx[:n_train]] = "train"
split_naive.loc[idx[n_train:n_train+n_val]] = "val"
split_naive.loc[idx[n_train+n_val:]] = "test"
df["split"] = split_naive.values

ov_tv, ov_tt, ov_vt = overlap(df)
n_leak = len(ov_tv | ov_tt | ov_vt)
print(f"[Ft-PARTICION-INGENUA] Grupos con fuga: train/val={len(ov_tv)}, train/test={len(ov_tt)}, val/test={len(ov_vt)} -> total={n_leak}")
with open(f"{EVID}/incidencia_particion_ingenua_Ft.json", "w") as f:
    json.dump({"grupos_con_fuga_total": n_leak, "train_val": sorted(ov_tv), "train_test": sorted(ov_tt),
               "val_test": sorted(ov_vt)}, f, indent=2, ensure_ascii=False)

# ---------- (b) Particion CORREGIDA (agrupada por group_id real) ----------
groups = df["group_id"].values
gss1 = GroupShuffleSplit(n_splits=1, train_size=0.70, random_state=42)
train_idx, rest_idx = next(gss1.split(df, groups=groups))
rest_df = df.iloc[rest_idx]
gss2 = GroupShuffleSplit(n_splits=1, train_size=0.5, random_state=42)
val_idx_rel, test_idx_rel = next(gss2.split(rest_df, groups=rest_df["group_id"].values))

final_split = pd.Series(index=df.index, dtype=object)
final_split.iloc[train_idx] = "train"
rest_index_arr = rest_df.index.values
final_split.loc[rest_index_arr[val_idx_rel]] = "val"
final_split.loc[rest_index_arr[test_idx_rel]] = "test"
df["split"] = final_split.values

ov_tv2, ov_tt2, ov_vt2 = overlap(df)
n_leak2 = len(ov_tv2 | ov_tt2 | ov_vt2)
assert n_leak2 == 0, "Aun existe fuga de datos"

conteo = df["split"].value_counts().to_dict()
grupos_por_split = df.groupby("split")["group_id"].nunique().to_dict()
clases = df.groupby(["split", "etiqueta_sunedu"]).size().unstack(fill_value=0)

print(f"[Ft-PARTICION-CORREGIDA] Fuga tras particion agrupada: {n_leak2} (debe ser 0)")
print(f"[Ft-PARTICION-CORREGIDA] Imagenes por particion: {conteo}")
print(f"[Ft-PARTICION-CORREGIDA] Estudiantes (grupos) por particion: {grupos_por_split}")
print(f"[Ft-PARTICION-CORREGIDA] Clases por particion:\n{clases}")

df[["id_imagen", "nombre_archivo", "group_id", "etiqueta_sunedu", "origen", "split"]].to_csv(
    f"{EVID}/dataset_split.csv", index=False)

with open(f"{EVID}/resumen_particion_Ft.json", "w") as f:
    json.dump({"grupos_con_fuga": n_leak2, "imagenes_por_particion": conteo,
               "estudiantes_por_particion": grupos_por_split, "clases_por_particion": clases.to_dict()},
              f, indent=2, ensure_ascii=False)
