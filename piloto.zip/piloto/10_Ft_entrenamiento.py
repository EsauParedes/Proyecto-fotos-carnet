"""
PILOTO Ft - Paso 3: P04 (preprocesamiento) + P05 (entrenamiento reducido)
----------------------------------------------------------------------------
Mismo diseño que 04_preprocesamiento_entrenamiento.py (stubs de sklearn como
sustituto temporal de ResNet-50/VGG-16 reales), pero ahora sobre 140
imagenes REALES (72 estudiantes) en vez de datos sinteticos.
"""
import os, json, csv, random, time
import numpy as np
import pandas as pd
from PIL import Image, ImageEnhance

random.seed(42)
np.random.seed(42)

RAW_DIR = "/home/claude/piloto/data_Ft_procesado"
EVID = "/home/claude/piloto/evidencias_Ft"
IMG_SIZE = (32, 32)  # reducido para velocidad del piloto (real: 224x224x3)

df = pd.read_csv(f"{EVID}/dataset_split.csv")

def load_and_preprocess(fname, augment=False):
    img = Image.open(os.path.join(RAW_DIR, fname)).convert("RGB").resize(IMG_SIZE)
    if augment:
        angle = random.uniform(-10, 10)
        img = img.rotate(angle, fillcolor=(255, 255, 255))
        img = ImageEnhance.Brightness(img).enhance(random.uniform(0.8, 1.2))
        img = ImageEnhance.Contrast(img).enhance(random.uniform(0.85, 1.15))
    arr = np.asarray(img.convert("L"), dtype=np.float32) / 255.0
    return arr.flatten()

X, y, split_arr, ids = [], [], [], []
n_aug = 0
for _, row in df.iterrows():
    augment = row["split"] == "train"
    X.append(load_and_preprocess(row["nombre_archivo"], augment=augment))
    y.append(1 if row["etiqueta_sunedu"] == "Conforme" else 0)
    split_arr.append(row["split"]); ids.append(row["id_imagen"])
    if augment: n_aug += 1

X = np.array(X); y = np.array(y); split_arr = np.array(split_arr); ids = np.array(ids)
print(f"[Ft-PREPROC] {len(X)} imagenes procesadas (resize {IMG_SIZE}, normalizado [0,1]); augmentation en {n_aug} de train")

Xtr, ytr = X[split_arr == "train"], y[split_arr == "train"]
Xval, yval = X[split_arr == "val"], y[split_arr == "val"]
Xte, yte = X[split_arr == "test"], y[split_arr == "test"]
ids_te = ids[split_arr == "test"]

from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                              balanced_accuracy_score, confusion_matrix, roc_auc_score)

SEEDS = [10, 20]
resultados = []
predicciones = {}
configs = {
    "stub_ResNet50": lambda s: RandomForestClassifier(n_estimators=200, max_depth=14, random_state=s),
    "stub_VGG16": lambda s: LogisticRegression(max_iter=1000, C=1.0, random_state=s),
}

def contar_parametros(clf, arch):
    if arch == "stub_ResNet50":
        return int(sum(t.tree_.node_count for t in clf.estimators_))
    return int(clf.coef_.size + clf.intercept_.size)

for arch, builder in configs.items():
    for seed in SEEDS:
        t0 = time.time()
        clf = builder(seed); clf.fit(Xtr, ytr)
        train_time = time.time() - t0
        val_pred = clf.predict(Xval) if len(Xval) else np.array([])
        t1 = time.time()
        test_pred = clf.predict(Xte)
        test_proba = clf.predict_proba(Xte)[:, 1]
        infer_t = (time.time() - t1) / max(len(Xte), 1)

        cm = confusion_matrix(yte, test_pred, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
        spec = tn / (tn + fp) if (tn + fp) > 0 else float("nan")
        try:
            auc = roc_auc_score(yte, test_proba) if len(set(yte)) > 1 else float("nan")
        except ValueError:
            auc = float("nan")

        metrics = dict(arch=arch, seed=seed, accuracy=accuracy_score(yte, test_pred),
                        precision=precision_score(yte, test_pred, zero_division=0),
                        recall=recall_score(yte, test_pred, zero_division=0),
                        f1=f1_score(yte, test_pred, zero_division=0),
                        balanced_accuracy=balanced_accuracy_score(yte, test_pred),
                        specificity=spec, auc_roc=auc, n_parametros_stub=contar_parametros(clf, arch),
                        train_time_s=round(train_time, 4), infer_time_per_image_s=round(infer_t, 6),
                        val_accuracy=accuracy_score(yval, val_pred) if len(yval) else None)
        resultados.append(metrics)
        predicciones[f"{arch}_seed{seed}"] = list(zip(ids_te.tolist(), yte.tolist(), test_pred.tolist(), test_proba.tolist()))

        with open(f"{EVID}/config_{arch}_seed{seed}.json", "w") as f:
            json.dump({"arquitectura_stub": arch, "seed": seed, "input_size_piloto": IMG_SIZE,
                       "input_size_real": [224, 224, 3], "n_train": len(Xtr), "n_val": len(Xval),
                       "n_test": len(Xte), "metrics_test": metrics}, f, indent=2, ensure_ascii=False)

resultados_df = pd.DataFrame(resultados)
resultados_df.to_csv(f"{EVID}/metrics_summary_Ft.csv", index=False)

for key, preds in predicciones.items():
    arch, seed_s = key.rsplit("_seed", 1)
    with open(f"{EVID}/predictions_{key}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["image_id", "true_class", "predicted_class", "model", "seed", "probability_conforme"])
        for iid, t, p, proba in preds:
            w.writerow([iid, t, p, arch, seed_s, round(proba, 4)])

print("\n[Ft-ENTRENAMIENTO] Resultados:")
print(resultados_df.to_string(index=False))
with open(f"{EVID}/resumen_entrenamiento_Ft.json", "w") as f:
    json.dump({"n_train": int(len(Xtr)), "n_val": int(len(Xval)), "n_test": int(len(Xte)),
               "seeds_piloto": SEEDS, "resultados": resultados_df.to_dict(orient="records")},
              f, indent=2, ensure_ascii=False)
