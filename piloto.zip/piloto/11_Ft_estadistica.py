"""
PILOTO Ft - Paso 4: P08 (linea base manual) + P11 (analisis estadistico) + P12
--------------------------------------------------------------------------------
Mismo diseño que 05_manual_y_estadistica.py, sobre el conjunto de prueba REAL
de 22 imagenes (11 estudiantes) del dataset Ft.
"""
import json
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.contingency_tables import mcnemar
from statsmodels.stats.multitest import multipletests

EVID = "/home/claude/piloto/evidencias_Ft"
rng = np.random.RandomState(7)

df_split = pd.read_csv(f"{EVID}/dataset_split.csv")
test_df = df_split[df_split["split"] == "test"].reset_index(drop=True)
n_test = len(test_df)

manual_rows = []
for _, row in test_df.iterrows():
    t = max(5, rng.normal(loc=26, scale=6))
    error_manual = rng.rand() < 0.08
    true_label = 1 if row["etiqueta_sunedu"] == "Conforme" else 0
    manual_pred = true_label if not error_manual else 1 - true_label
    manual_rows.append(dict(image_id=row["id_imagen"], true_class=true_label,
                             manual_pred=manual_pred, tiempo_seg=round(t, 2)))
manual_df = pd.DataFrame(manual_rows)
manual_df.to_csv(f"{EVID}/manual_eval_SIMULADO_Ft.csv", index=False)
print(f"[Ft-MANUAL-SIMULADO] {n_test} imagenes. Tiempo promedio simulado: {manual_df['tiempo_seg'].mean():.2f}s")

auto_resnet = pd.read_csv(f"{EVID}/predictions_stub_ResNet50_seed10.csv")
auto_vgg = pd.read_csv(f"{EVID}/predictions_stub_VGG16_seed10.csv")
resumen_train = json.load(open(f"{EVID}/resumen_entrenamiento_Ft.json"))

def infer_time_de(arch, seed):
    return next(r["infer_time_per_image_s"] for r in resumen_train["resultados"] if r["arch"] == arch and r["seed"] == seed)

def merge_con_manual(auto_df, arch):
    m = manual_df.merge(auto_df, on=["image_id", "true_class"], how="inner")
    m["tiempo_auto_seg"] = infer_time_de(arch, 10)
    return m

merged_resnet = merge_con_manual(auto_resnet, "stub_ResNet50")
merged_vgg = merge_con_manual(auto_vgg, "stub_VGG16")
merged_rv = auto_resnet.merge(auto_vgg, on=["image_id", "true_class"], suffixes=("_resnet", "_vgg"))

def mcnemar_or(correct_a, correct_b):
    tabla = pd.crosstab(correct_a, correct_b)
    for i in [0, 1]:
        if i not in tabla.index: tabla.loc[i] = [0, 0]
        if i not in tabla.columns: tabla[i] = 0
    tabla = tabla.sort_index()[sorted(tabla.columns)]
    b = tabla.loc[1, 0] if (1 in tabla.index and 0 in tabla.columns) else 0
    c = tabla.loc[0, 1] if (0 in tabla.index and 1 in tabla.columns) else 0
    b_adj, c_adj = (b + 0.5, c + 0.5) if (b == 0 or c == 0) else (b, c)
    odds_ratio = b_adj / c_adj
    res = mcnemar(tabla.values, exact=(tabla.values.sum() < 25))
    return tabla, float(res.statistic), float(res.pvalue), float(odds_ratio)

manual_correct = (merged_resnet["manual_pred"] == merged_resnet["true_class"]).astype(int)
resnet_correct = (merged_resnet["predicted_class"] == merged_resnet["true_class"]).astype(int)
vgg_correct = (merged_vgg["predicted_class"] == merged_vgg["true_class"]).astype(int)
resnet_correct_rv = (merged_rv["predicted_class_resnet"] == merged_rv["true_class"]).astype(int)
vgg_correct_rv = (merged_rv["predicted_class_vgg"] == merged_rv["true_class"]).astype(int)

tabla1, stat1, p1, or1 = mcnemar_or(manual_correct, resnet_correct)
tabla2, stat2, p2, or2 = mcnemar_or(manual_correct, vgg_correct)
tabla3, stat3, p3, or3 = mcnemar_or(resnet_correct_rv, vgg_correct_rv)

comparaciones = ["manual_vs_stubResNet50", "manual_vs_stubVGG16", "stubResNet50_vs_stubVGG16"]
pvalues = [p1, p2, p3]; odds_ratios = [or1, or2, or3]; stats_ = [stat1, stat2, stat3]
reject, pvals_corr, _, _ = multipletests(pvalues, alpha=0.05, method="holm")

print("\n[Ft-MCNEMAR+OR] (correccion Holm-Bonferroni)")
for comp, st, p, orr, pc, rj in zip(comparaciones, stats_, pvalues, odds_ratios, pvals_corr, reject):
    print(f"  {comp}: stat={st:.3f} p={p:.4f} OR={orr:.3f} p_corr={pc:.4f} sig={rj}")

shapiro_manual = stats.shapiro(merged_vgg["tiempo_seg"])
print(f"\n[Ft-SHAPIRO] W={shapiro_manual.statistic:.4f} p={shapiro_manual.pvalue:.4f}")
if shapiro_manual.pvalue > 0.05 and merged_vgg["tiempo_auto_seg"].nunique() > 1:
    tt = stats.ttest_ind(merged_vgg["tiempo_seg"], merged_vgg["tiempo_auto_seg"], equal_var=False)
    time_test, time_stat, time_p = "t de Student (Welch)", tt.statistic, tt.pvalue
else:
    try:
        wt = stats.wilcoxon(merged_vgg["tiempo_seg"], merged_vgg["tiempo_auto_seg"])
        time_test, time_stat, time_p = "Wilcoxon", wt.statistic, wt.pvalue
    except ValueError:
        time_test, time_stat, time_p = "Wilcoxon (no aplicable)", float("nan"), float("nan")
print(f"[Ft-TIEMPOS] {time_test}: stat={time_stat} p={time_p}")
reduccion = 100 * (1 - merged_vgg["tiempo_auto_seg"].mean() / merged_vgg["tiempo_seg"].mean())
print(f"[Ft-TIEMPOS] Reduccion de tiempo (simulada): {reduccion:.2f}%")

meta = pd.read_csv(f"{EVID}/dataset_metadata.csv")
merged2 = merged_vgg.merge(meta[["id_imagen", "criterios_incumplidos"]], left_on="image_id", right_on="id_imagen", how="left")
merged2["error_automatizado"] = merged2["predicted_class"] != merged2["true_class"]
errores_por_criterio = merged2[merged2["error_automatizado"]]["criterios_incumplidos"].value_counts()
n_fn = int(((merged2["error_automatizado"]) & (merged2["true_class"] == 1)).sum())
n_fp = int(((merged2["error_automatizado"]) & (merged2["true_class"] == 0)).sum())
print(f"\n[Ft-ERRORES] stub_VGG16: {n_fn} falsos negativos, {n_fp} falsos positivos")
print(errores_por_criterio)

resultado = {
    "n_test": int(len(merged_vgg)),
    "comparaciones_pareadas": [
        {"comparacion": c, "estadistico_mcnemar": s, "p_value": p, "odds_ratio": o,
         "p_value_corregido_holm": float(pc), "significativo_alpha_0.05": bool(rj)}
        for c, s, p, o, pc, rj in zip(comparaciones, stats_, pvalues, odds_ratios, pvals_corr, reject)
    ],
    "shapiro_wilk_tiempos_manual": {"W": float(shapiro_manual.statistic), "p_value": float(shapiro_manual.pvalue)},
    "prueba_tiempos": {"nombre": time_test, "estadistico": float(time_stat) if time_stat == time_stat else None,
                        "p_value": float(time_p) if time_p == time_p else None},
    "reduccion_tiempo_pct_simulado": float(reduccion),
    "errores_por_criterio": errores_por_criterio.to_dict(), "falsos_negativos": n_fn, "falsos_positivos": n_fp,
}
with open(f"{EVID}/resultado_analisis_estadistico_Ft.json", "w") as f:
    json.dump(resultado, f, indent=2, ensure_ascii=False)
merged2.to_csv(f"{EVID}/comparacion_manual_vs_automatizado_Ft.csv", index=False)
