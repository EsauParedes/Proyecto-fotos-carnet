import json, os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import numpy as np

EVID = "/home/claude/piloto/evidencias_Ft"
FIG = "/home/claude/piloto/figuras_Ft"
os.makedirs(FIG, exist_ok=True)

pred = pd.read_csv(f"{EVID}/predictions_stub_VGG16_seed10.csv")
cm = confusion_matrix(pred["true_class"], pred["predicted_class"], labels=[0, 1])
fig, ax = plt.subplots(figsize=(4, 4))
ax.imshow(cm, cmap="Blues")
for i in range(2):
    for j in range(2):
        ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=14)
ax.set_xticks([0, 1]); ax.set_xticklabels(["No conforme", "Conforme"])
ax.set_yticks([0, 1]); ax.set_yticklabels(["No conforme", "Conforme"])
ax.set_xlabel("Predicho"); ax.set_ylabel("Real")
ax.set_title("Matriz de confusión - stub_VGG16 (datos reales Ft, n=22)")
plt.tight_layout(); plt.savefig(f"{FIG}/matriz_confusion_Ft.png", dpi=140); plt.close()

metrics_df = pd.read_csv(f"{EVID}/metrics_summary_Ft.csv")
agg = metrics_df.groupby("arch")[["accuracy", "f1", "balanced_accuracy", "specificity", "auc_roc"]].mean()
fig, ax = plt.subplots(figsize=(7, 4))
agg.plot(kind="bar", ax=ax); ax.set_ylim(0, 1)
ax.set_title("Métricas promedio por arquitectura-stub (datos REALES Ft)")
plt.xticks(rotation=0); plt.legend(loc="lower right", fontsize=8)
plt.tight_layout(); plt.savefig(f"{FIG}/metricas_por_arquitectura_Ft.png", dpi=140); plt.close()

resultado_stats = json.load(open(f"{EVID}/resultado_analisis_estadistico_Ft.json"))
comps = resultado_stats["comparaciones_pareadas"]
fig, ax = plt.subplots(figsize=(6, 4))
nombres = [c["comparacion"].replace("_", "\n") for c in comps]
ors = [c["odds_ratio"] for c in comps]
colors = ["#2471a3" if not c["significativo_alpha_0.05"] else "#c0392b" for c in comps]
ax.bar(nombres, ors, color=colors); ax.axhline(1.0, color="gray", linestyle="--")
ax.set_ylabel("Odds ratio (McNemar)")
ax.set_title("Tamaño de efecto por comparación (datos reales Ft)")
plt.tight_layout(); plt.savefig(f"{FIG}/odds_ratio_comparaciones_Ft.png", dpi=140); plt.close()

comp = pd.read_csv(f"{EVID}/comparacion_manual_vs_automatizado_Ft.csv")
fig, ax = plt.subplots(figsize=(5, 4))
vals = [comp["tiempo_seg"].mean(), comp["tiempo_auto_seg"].mean()]
ax.bar(["Manual (simulado)", "Automatizado (stub)"], vals, color=["#c0392b", "#2471a3"])
ax.set_ylabel("Tiempo promedio por imagen (s)")
ax.set_title("Tiempo: manual (simulado) vs automatizado — datos reales")
for i, v in enumerate(vals):
    ax.text(i, v, f"{v:.3f}s", ha="center", va="bottom")
plt.tight_layout(); plt.savefig(f"{FIG}/tiempo_manual_vs_automatizado_Ft.png", dpi=140); plt.close()

print("[Ft-FIGURAS] Generadas: matriz_confusion_Ft.png, metricas_por_arquitectura_Ft.png, odds_ratio_comparaciones_Ft.png, tiempo_manual_vs_automatizado_Ft.png")
