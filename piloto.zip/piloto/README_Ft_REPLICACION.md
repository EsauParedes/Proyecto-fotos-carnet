# Piloto con base de datos real de 72 estudiantes — Guía de replicación en Colab

Este es el piloto más representativo hasta ahora: usa **72 fotografías reales**, cada una de un
estudiante distinto (identificado por su código de 8 dígitos, usado directamente como `group_id`),
en lugar de datos sintéticos o de una sola persona.

## Resumen de resultados obtenidos

| Paso | Resultado |
|---|---|
| Auditoría de las 72 fotos originales (8 criterios oficiales SUNEDU) | 68 Conforme / 4 No conforme (94%/6% — muy desbalanceado) |
| Balanceo (protocolo V1.3, sección 2.5: degradar copias) | 140 imágenes, 68 Conforme / 72 No conforme (49%/51%) |
| Partición ingenua (sin agrupar) | **42 de 72 estudiantes** con fuga de datos (fotos del mismo estudiante en distintas particiones) |
| Partición agrupada (GroupShuffleSplit + verificación) | Fuga = 0 confirmada. train=97 (50 estudiantes), val=21 (11), test=22 (11) |
| Entrenamiento (stub_ResNet50 / stub_VGG16, 2 semillas) | Accuracy ≈ 0.77, AUC-ROC 0.79–0.89 — el modelo aprende señal real (a diferencia del piloto sintético, donde predecía solo la clase mayoritaria) |
| McNemar + odds ratio + Holm-Bonferroni | 3 comparaciones pareadas, ninguna significativa aún (manual simulado vs. automatizado) |

## Cómo replicar esto con TU propia colección de fotos

1. **Reúne tus fotos reales**, nombradas con el código de cada estudiante (ej. `12345678.jpg`),
   ya en formato 240×288 / 300 dpi / 4-50 KB (usa el corrector del piloto de una sola persona,
   `07_fotos_reales.py`, si necesitas convertir fotos crudas a este formato).
2. **Sube la carpeta a Google Drive** y móntala en Colab (Paso 0 del notebook).
3. Si tu colección natural **ya tiene suficientes fotos reales "No conforme"** (estudiantes que de
   hecho fallaron la validación), **omite el bloque de degradación** del Paso 1 — es preferible usar
   negativos reales que degradar artificialmente. Si no, el bloque de degradación ya implementado
   genera esos ejemplos automáticamente de forma reproducible (semilla fija = 42).
4. Ejecuta el notebook `Piloto_Ft_Colab.ipynb` de principio a fin.
5. Verifica `resumen_particion_Ft.json`: el campo `grupos_con_fuga` debe ser `0` antes de confiar en
   cualquier métrica reportada.
6. Para la ejecución real a escala completa (~1000 fotos), reemplaza los datos simulados del Paso 4
   (tiempos/decisión manual) por tu propia revisión cronometrada, y confirma que `REAL_MODELS_OK` sea
   `True` (necesitas Colab con internet para descargar los pesos ImageNet de ResNet-50/VGG-16).

## Archivos de este módulo

```
piloto/
├── 08_Ft_auditoria.py       # registro + auditoría 8 criterios + balanceo (degradación)
├── 09_Ft_particion.py       # partición ingenua vs. agrupada + verificación de fuga
├── 10_Ft_entrenamiento.py   # preprocesamiento + entrenamiento + métricas completas
├── 11_Ft_estadistica.py     # manual simulado + McNemar+OR+Holm-Bonferroni + Shapiro-Wilk
├── 12_Ft_figuras.py         # figuras de evidencia
├── Piloto_Ft_Colab.ipynb    # notebook todo-en-uno, listo para Google Colab
├── data_Ft_raw/             # las 72 fotos originales
├── data_Ft_procesado/       # 140 fotos (72 originales + 68 degradadas)
├── evidencias_Ft/           # CSV/JSON de cada paso
└── figuras_Ft/              # PNG de evidencia
```
