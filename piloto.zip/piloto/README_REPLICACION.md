# Cómo replicar este piloto con tus fotografías reales en Google Colab

Este piloto se ejecutó con un **dataset sintético** (78 imágenes generadas por
código, cubriendo los 9 criterios de conformidad del Anexo 3 de la tesis)
porque el entorno de piloto no tiene acceso a internet hacia el validador de
SUNEDU ni hacia los servidores de pesos de ImageNet. El objetivo de este
piloto fue probar que el **código del pipeline funciona correctamente**, no
obtener resultados científicos. A continuación se explica, paso a paso, cómo
reemplazar cada parte simulada por la real, usando Google Colab (que sí tiene
internet).

## ¿Por qué 78 imágenes? (justificación del tamaño de muestra)

1. **Julious (2005):** regla de ≥12 observaciones por clase para un piloto sin
   información previa de variabilidad. Las dos clases (Conforme=24, No
   conforme=47) superan ese mínimo.
2. **Hertzog (2008):** un piloto suele representar 10-20% del dataset final
   (~1000 fotos). Estas 78 imágenes son ~8%, deliberadamente algo menor porque
   este piloto prueba únicamente el *código*, no la variabilidad estadística
   real — para eso se recomienda un piloto ampliado de ~100 fotos reales.
3. **Cobertura de los 9 criterios del Anexo 3:** cada criterio (dimensión,
   dpi, nitidez, fondo, rostro frontal, ojos abiertos, boca cerrada, sin
   accesorios, formato) recibe 4-8 ejemplos generados a propósito, más los
   casos límite (corruptos, duplicados) — suficiente para ejercitar cada rama
   del código de auditoría varias veces.

## Mapa: qué se simuló aquí → qué debes hacer tú con datos reales

| Paso del protocolo | En este piloto (sandbox sin internet) | Lo que harás tú en Colab con tus fotos |
|---|---|---|
| P01 Registro | 61 imágenes generadas con PIL (`01_generar_dataset.py`) | Tus fotografías reales de estudiantes, obtenidas de OTI-UNAJ con autorización |
| P01 Etiquetado (ground truth) | Función `validador_sunedu_SIMULADO()` con reglas propias que cubren los 9 criterios del Anexo 3 (dimensión, dpi, nitidez, fondo, rostro frontal, ojos abiertos, boca cerrada, sin accesorios, formato) | Subir cada foto a **https://siucarne.sunedu.gob.pe/carne/validacion** tú mismo y registrar el resultado real (Conforme/No conforme) |
| P02 Auditoría | Hash SHA-256 + `PIL.Image.verify()` + heurísticas propias (fondo, nitidez, pose, ojos, boca, accesorios). Esquema de columnas ya idéntico al Anexo 3 (`id_imagen`, `nombre_archivo`, `etiqueta_sunedu`, etc.) | Igual, pero puedes conservar las heurísticas como **pre-filtro opcional** antes de gastar tiempo subiendo fotos al validador oficial (ver advertencia de calibración abajo) |
| P03 Partición | `GroupShuffleSplit` de scikit-learn por `group_id` sintético | Igual, pero `group_id` = código de estudiante real |
| P04 Preprocesamiento | Resize a 32×32 (velocidad) | Resize real a **224×224×3**, igual que aquí pero a tamaño completo |
| P05 Entrenamiento | `RandomForestClassifier` y `LogisticRegression` de scikit-learn (stand-ins) | **ResNet-50** y **VGG-16** reales de `tensorflow.keras.applications`, con pesos `imagenet` (esto requiere internet, por eso se hace en Colab) |
| P08 Revisión manual | Tiempos y decisiones generados aleatoriamente | Tú mismo revisando y cronometrando cada foto del conjunto de prueba |
| P11 Análisis estadístico | McNemar + **odds ratio** (3 comparaciones pareadas: manual vs ResNet, manual vs VGG, ResNet vs VGG) + corrección **Holm-Bonferroni** + Shapiro-Wilk + Wilcoxon/t (código real, datos simulados) | Mismo código, exactamente igual, sobre tus datos reales |

## Pasos exactos en Google Colab

1. **Crear una carpeta en Google Drive**, p. ej. `TesisII_UNAJ/dataset/`, y subir tus
   fotografías reales (o las de tus compañeros voluntarios, con consentimiento).

2. **Montar Drive en Colab**:
   ```python
   from google.colab import drive
   drive.mount('/content/drive')
   RAW_DIR = "/content/drive/MyDrive/TesisII_UNAJ/dataset/data_raw"
   ```

3. **Etiquetar cada foto con el validador oficial de SUNEDU** (esto NO se hace
   en Colab, se hace manualmente en tu navegador):
   - Entra a https://siucarne.sunedu.gob.pe/carne/validacion
   - Sube cada fotografía candidata
   - Registra el resultado en una hoja de cálculo o CSV con columnas:
     `image_id, file_name, resultado_sunedu, criterio_incumplido`
   - Sube ese CSV a la misma carpeta de Drive.

4. **Reutilizar el código de auditoría** (`02_auditoria.py` de este piloto):
   cambia solo la parte de la función `validador_sunedu_SIMULADO()` — en la
   versión real, en lugar de calcular una decisión, **lees la columna
   `resultado_sunedu`** de tu CSV de etiquetado y la usas directamente como
   `class_label`. El resto del script (hash, `Image.verify()`, cálculo de
   `bg_ratio` y `sharpness` como pre-filtro opcional) se reutiliza sin cambios.

5. **Reutilizar el código de partición** (`03_particion.py`) tal cual —
   solo cambia `group_id` para que provenga del código real de estudiante.
   Ejecuta primero la partición ingenua para confirmar (o no) fuga, y luego
   la partición agrupada; guarda ambos resultados como evidencia.

6. **Instalar TensorFlow y descargar los pesos ImageNet** (esto solo funciona
   con internet, por eso se hace en Colab y no en el piloto):
   ```python
   !pip install tensorflow
   from tensorflow.keras.applications import ResNet50, VGG16
   base_resnet = ResNet50(weights="imagenet", include_top=False, input_shape=(224,224,3))
   base_vgg = VGG16(weights="imagenet", include_top=False, input_shape=(224,224,3))
   ```
   Luego añade tu cabeza de clasificación binaria, congela/descongela capas
   según la sección 2.6 del protocolo, y entrena con los hiperparámetros ya
   fijados (learning rate 1e-4, batch 32, máx. 50 épocas, early stopping
   paciencia 10).

7. **Reutilizar sin cambios** los scripts `05_manual_y_estadistica.py` (pero
   reemplazando los tiempos/decisiones simulados por los tuyos, cronometrados
   de verdad) y `06_figuras_y_reproducibilidad.py`.

8. **Guardar todo en Drive**: configuraciones (`.json`), checkpoints (`.h5`),
   predicciones (`.csv`), métricas, figuras y logs — exactamente con los
   mismos nombres de archivo que usa este piloto, para mantener la
   trazabilidad descrita en el Protocolo V1.2 y la Matriz de Trazabilidad.

## Advertencia sobre las heurísticas de pre-filtro (bg_ratio, nitidez)

Durante este piloto se detectó que un umbral mal calibrado (`bg_ratio ≥ 0.85`)
rechazaba incluso fotos con fondo correctamente blanco, porque el ruido
agregado a las imágenes sintéticas bajaba el ratio a 0.848. Se corrigió a
`bg_ratio ≥ 0.80` y `sharpness ≥ 100`, alineado con el criterio ya usado en el
Anexo 3 de la tesis. **Si usas estas heurísticas como pre-filtro opcional
antes de enviar fotos al validador oficial**, calibra primero los
umbrales contra 10-15 fotos con resultado oficial ya conocido, para evitar
descartar fotos válidas por error.

## Archivos de este piloto (referencia)

```
piloto/
├── 01_generar_dataset.py              # genera datos sintéticos (NO USAR con datos reales)
├── 02_auditoria.py                    # reutilizable: registro + auditoría + validador (cambiar el validador)
├── 03_particion.py                    # reutilizable tal cual
├── 04_preprocesamiento_entrenamiento.py  # reutilizable, pero cambiar los "stubs" por ResNet50/VGG16 reales
├── 05_manual_y_estadistica.py         # reutilizable, cambiar datos simulados por reales
├── 06_figuras_y_reproducibilidad.py   # reutilizable tal cual
├── data_raw/                          # imágenes sintéticas del piloto
├── evidencias/                        # todos los CSV/JSON generados (ver Informe de Pilotaje V1)
├── figuras/                           # gráficos de evidencia
└── logs/                              # salida de consola de cada paso (trazabilidad)
```
